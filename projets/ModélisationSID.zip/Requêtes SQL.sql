-- Requêtes SQL pour l'analyse et le reporting de la base de données des franchises dentaires


-- ==============================================================================
-- A. Analyse de la Patientèle
-- ==============================================================================

-- 1.Répartition simple des patients par Ville et par Sexe
SELECT 
    ville, 
    sexe, 
    COUNT(*) as nombre_patients
FROM Patients
GROUP BY ville, sexe
ORDER BY nombre_patients DESC;

--2.Combien de nouveaux dossiers ont été ouverts par année ?
SELECT 
    TO_CHAR(date_creation, 'YYYY') as annee_creation, 
    COUNT(*) as nombre_nouveaux_dossiers
FROM Dossiers_Patients
GROUP BY TO_CHAR(date_creation, 'YYYY')
ORDER BY annee_creation DESC;


-- ==============================================================================
-- B. Analyse des Dossiers et Actes Médicaux
-- ==============================================================================

--3. Dossiers Ouverts vs Fermés
SELECT etat, COUNT(*) AS nombre_dossiers
FROM Dossiers_Patients
GROUP BY etat;

--4. Statistiques sur les Actes Médicaux (Prix moyen et Volume par type)
SELECT 
    type_acte,
    COUNT(*) AS volume_actes,
    ROUND(AVG(montant), 2) AS prix_moyen,
    SUM(montant) AS chiffre_affaires_total
FROM Actes_Medicaux
GROUP BY type_acte
ORDER BY chiffre_affaires_total DESC;

--5. Temps moyen par traitement (Durée des traitements)
SELECT 
    ROUND(AVG(date_fin - date_debut), 0) || ' jours' AS duree_moyenne_jours
FROM Traitements
WHERE date_debut IS NOT NULL AND date_fin IS NOT NULL;


-- ==============================================================================
-- C. Analyse des Coûts et Revenus
-- ==============================================================================

-- 6.Revenu par type de soins
SELECT 
    type_acte,
    SUM(montant) AS revenu_total,
    COUNT(*) AS nombre_actes,
    ROUND(AVG(montant), 2) AS revenu_moyen
FROM Actes_Medicaux
GROUP BY type_acte
ORDER BY revenu_total DESC;

--7. Revenu Mensuel (Évolution du CA)
SELECT 
    TO_CHAR(date_acte, 'YYYY-MM') AS mois,
    SUM(montant) AS revenu_mensuel
FROM Actes_Medicaux
GROUP BY TO_CHAR(date_acte, 'YYYY-MM')
ORDER BY mois DESC;

--8. Revenu Annuel (Évolution du CA)
SELECT 
    TO_CHAR(date_acte, 'YYYY') AS annee,
    SUM(montant) AS revenu_annuel
FROM Actes_Medicaux
GROUP BY TO_CHAR(date_acte, 'YYYY')
ORDER BY annee DESC;

--9. Paiements en Retard (Facturé vs Encaissé par Patient)  
--Cette requête compare la somme des actes réalisés par un patient avec la somme de ses paiements.
SELECT 
    P.nom || ' ' || P.prenom AS patient,
    COALESCE(SUM(A.montant), 0) AS total_facture,
    COALESCE(pay.total_paye, 0) AS total_encaisse,
    (COALESCE(SUM(A.montant), 0) - COALESCE(pay.total_paye, 0)) AS reste_a_payer
FROM Patients P
JOIN Dossiers_Patients D ON P.id_patient = D.id_patient
JOIN Actes_Medicaux A ON D.id_dossier = A.id_dossier
LEFT JOIN (
    SELECT id_patient, SUM(montant) as total_paye 
    FROM Paiements 
    GROUP BY id_patient
) pay ON P.id_patient = pay.id_patient
GROUP BY P.nom, P.prenom, pay.total_paye
HAVING (COALESCE(SUM(A.montant), 0) - COALESCE(pay.total_paye, 0)) > 0
ORDER BY reste_a_payer DESC;


-- ==============================================================================
-- D. Performance du Personnel 
-- ==============================================================================

--10. Efficacité des Praticiens (CA généré et nombre de consultations)
SELECT 
    PERS.nom || ' ' || PERS.prenom AS praticien,
    PERS.role,
    COUNT(A.id_acte) AS nombre_actes,
    SUM(A.montant) AS ca_genere
FROM Personnel PERS
JOIN Actes_Medicaux A ON PERS.id_personnel = A.id_praticien
GROUP BY PERS.nom, PERS.prenom, PERS.role
ORDER BY ca_genere DESC;

--11. Nombre de consultations par praticien
SELECT 
    PERS.nom || ' ' || PERS.prenom AS praticien,
    PERS.role,
    PERS.specialite,
    COUNT(A.id_acte) AS nombre_consultations
FROM Personnel PERS
JOIN Actes_Medicaux A ON PERS.id_personnel = A.id_praticien
GROUP BY PERS.nom, PERS.prenom, PERS.role, PERS.specialite
ORDER BY nombre_consultations DESC;


-- ==============================================================================
-- E. Gestion des Équipements et Consommables  
-- ==============================================================================

--12. Produits en Alerte de Stock (Besoins de commande)  Requête essentielle pour la logistique.
SELECT 
    F.nom_franchise,
    SP.nom_produit,
    SP.quantite_stock,
    SP.seuil_alerte
FROM Produits_Dentaires SP
JOIN Franchises F ON SP.id_franchise = F.id_franchise
WHERE SP.quantite_stock <= SP.seuil_alerte
ORDER BY SP.quantite_stock ASC;

--13. Historique des commandes
SELECT 
    C.id_commande,
    F.nom_franchise,
    FOUR.nom_fournisseur,
    C.date_commande,
    C.statut,
    SUM(LC.QUANTITE) AS nombre_produits,
    SUM(LC.quantite * LC.prix_unitaire) AS montant_total
FROM Commandes C
JOIN Franchises F ON C.id_franchise = F.id_franchise
JOIN Fournisseurs FOUR ON C.id_fournisseur = FOUR.id_fournisseur
LEFT JOIN Lignes_Commande LC ON C.id_commande = LC.id_commande
GROUP BY C.id_commande, F.nom_franchise, FOUR.nom_fournisseur, C.date_commande, C.statut
ORDER BY C.date_commande DESC;


-- ==============================================================================
-- F. Analyse de l'État Buccal et Dentaire (partie importante du pdf)
-- ==============================================================================

--14. Dents les plus sujettes aux anomalies (Top des dents malades)  Permet de savoir quelles dents (ex: molaires 36, 46) sont les plus souvent soignées
SELECT 
    D.code_fdi AS numero_dent,
    COUNT(A.id_anomalie) AS nombre_anomalies
FROM Dents D
JOIN Etat_Dents_Historique E ON D.id_dent = E.id_dent
JOIN Anomalies A ON E.id_etat = A.id_etat
GROUP BY D.code_fdi
ORDER BY nombre_anomalies DESC;

--15. Répartition des types d'anomalies (Prévention)  Quelle pathologie est la plus fréquente (Carie, Fracture...)
SELECT 
    type_anomalie,
    COUNT(*) AS frequence,
    ROUND(COUNT(*) * 100 / (SELECT COUNT(*) FROM Anomalies), 2) || '%' AS pourcentage
FROM Anomalies
GROUP BY type_anomalie
ORDER BY frequence DESC;

--16. Historique complet d'un patient spécifique (Ex: Nom du Patient : Simon)  
--Pour voir l'évolution : Dent saine -> Anomalie -> Extraction -> Implant.
SELECT 
    P.nom || ' ' || P.prenom as patient,
    D.code_fdi AS dent,
    E.date_observation,
    E.type_etat,
    COALESCE(AN.type_anomalie, R.type_restauration) AS detail_pathologie,
    E.detail_etat
FROM Patients P
JOIN Dents D ON P.id_patient = D.id_patient
JOIN Etat_Dents_Historique E ON D.id_dent = E.id_dent
LEFT JOIN Anomalies AN ON E.id_etat = AN.id_etat
LEFT JOIN Restaurations R ON E.id_etat = R.id_etat
WHERE P.NOM = 'Simon'
ORDER BY E.date_observation;

--17. Tendances des restaurations par sexe
SELECT 
    P.sexe,
    R.type_restauration,
    COUNT(*) AS nombre_restaurations,
    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (PARTITION BY P.sexe), 2) AS pourcentage_par_sexe
FROM Patients P
JOIN Dents D ON P.id_patient = D.id_patient
JOIN Etat_Dents_Historique E ON D.id_dent = E.id_dent
JOIN Restaurations R ON E.id_etat = R.id_etat
GROUP BY P.sexe, R.type_restauration
ORDER BY P.sexe, nombre_restaurations DESC;


-- ==============================================================================
-- G. Analyse de la Fréquentation des Franchises 
-- ==============================================================================

--18. Répartition des Patients par Franchise
SELECT 
    F.nom_franchise,
    F.ville,
    COUNT(P.id_patient) AS nombre_patients_rattaches
FROM Franchises F
LEFT JOIN Patients P ON F.id_franchise = P.id_franchise_principale
GROUP BY F.nom_franchise, F.ville
Order by nombre_patients_rattaches DESC;

--19. Chiffre d'Affaires par Franchise. Top 3 des franchises générant le plus de CA.
SELECT 
    F.nom_franchise,
    COUNT(A.id_acte) AS volume_actes,
    SUM(A.montant) AS chiffre_affaires
FROM Franchises F
JOIN Personnel PERS ON F.id_franchise = PERS.id_franchise
JOIN Actes_Medicaux A ON PERS.id_personnel = A.id_praticien
GROUP BY F.nom_franchise
ORDER BY chiffre_affaires DESC 
FETCH FIRST 3 ROWS ONLY;

--20. Évolution des dossiers patients par franchise
SELECT 
    F.nom_franchise,
    TO_CHAR(D.date_creation, 'YYYY') AS annee,
    COUNT(D.id_dossier) AS nombre_nouveaux_dossiers
FROM Franchises F
JOIN Patients P ON F.id_franchise = P.id_franchise_principale
JOIN Dossiers_Patients D ON P.id_patient = D.id_patient
GROUP BY F.nom_franchise, TO_CHAR(D.date_creation, 'YYYY')
ORDER BY F.nom_franchise, annee DESC ;


-- ==============================================================================
-- H : Suivi des depenses et rentabilité
-- ==============================================================================

--21. Répartition des dépenses par moyen de paiement
SELECT 
    moyen_paiement,
    ROUND(AVG(montant), 2) AS montant_moyen,
    ROUND(SUM(montant) * 100.0 / (SELECT SUM(montant) FROM Paiements), 2) AS utilisation_moyen_paiement
FROM Paiements
GROUP BY moyen_paiement
ORDER BY utilisation_moyen_paiement DESC;

--22. Évolution des dépenses et revenus par trimestre
SELECT 
    TO_CHAR(date_acte, 'YYYY-Q') AS trimestre,
    SUM(montant) AS revenus_total,
    SUM(depenses) AS depenses_total,
    SUM(montant - depenses) AS benefice_net
FROM (
    SELECT date_acte, montant, 0 AS depenses
    FROM Actes_Medicaux
    
    UNION ALL
    
    SELECT C.date_commande AS date_acte, 0 AS montant, SUM(LC.quantite * LC.prix_unitaire) AS depenses
    FROM Commandes C
    JOIN Lignes_Commande LC ON C.id_commande = LC.id_commande
    GROUP BY C.date_commande
)
GROUP BY TO_CHAR(date_acte, 'YYYY-Q')
ORDER BY trimestre DESC;
