-- Jeu de Données de Test pour la gestion des franchises Dentissimo

-- ==============================================================================
-- FRANCHISES (11 lignes)
-- ==============================================================================
INSERT INTO Franchises (id_franchise, nom_franchise, adresse, ville, telephone) VALUES (1, 'Dentissimo Niort', '12 Place de la Brèche', 'Niort', '0101010101');
INSERT INTO Franchises (id_franchise, nom_franchise, adresse, ville, telephone) VALUES (2, 'Dentissimo Paris Sud', '45 Av d''Italie', 'Paris', '0102020202');
INSERT INTO Franchises (id_franchise, nom_franchise, adresse, ville, telephone) VALUES (3, 'Dentissimo Lyon Part-Dieu', '10 Rue Servient', 'Lyon', '0404040404');
INSERT INTO Franchises (id_franchise, nom_franchise, adresse, ville, telephone) VALUES (4, 'Dentissimo Lyon Bellecour', '5 Place Bellecour', 'Lyon', '0405050505');
INSERT INTO Franchises (id_franchise, nom_franchise, adresse, ville, telephone) VALUES (5, 'Dentissimo Marseille Vieux-Port', '1 Quai du Port', 'Marseille', '0491919191');
INSERT INTO Franchises (id_franchise, nom_franchise, adresse, ville, telephone) VALUES (6, 'Dentissimo Bordeaux', '20 Rue Sainte-Catherine', 'Bordeaux', '0556565656');
INSERT INTO Franchises (id_franchise, nom_franchise, adresse, ville, telephone) VALUES (7, 'Dentissimo Lille', '8 Place de la Gare', 'Lille', '0320202020');
INSERT INTO Franchises (id_franchise, nom_franchise, adresse, ville, telephone) VALUES (8, 'Dentissimo Toulouse', '12 Place du Capitole', 'Toulouse', '0561616161');
INSERT INTO Franchises (id_franchise, nom_franchise, adresse, ville, telephone) VALUES (9, 'Dentissimo Nice', '50 Promenade des Anglais', 'Nice', '0493939393');
INSERT INTO Franchises (id_franchise, nom_franchise, adresse, ville, telephone) VALUES (10, 'Dentissimo Nantes', '4 Rue Crébillon', 'Nantes', '0240404040');
INSERT INTO Franchises (id_franchise, nom_franchise, adresse, ville, telephone) VALUES (11, 'Dentissimo Paris Nord', '12 Rue de la Chapelle', 'Paris', '0101010101');


-- ==============================================================================
-- PERSONNEL (42 lignes)
-- ==============================================================================
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (1, 1, 'Martin', 'Sophie', 'Dentiste', 'Chirurgie', 's.martin@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (6, 1, 'Bernard', 'Thomas', 'Assistant', NULL, 't.bernard@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (7, 1, 'Leroy', 'Alice', 'Hygieniste', NULL, 'a.leroy@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (2, 2, 'Thomas', 'Franc', 'Dentiste', 'Implantologie', 't.franc@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (3, 2, 'Petit', 'Julie', 'Dentiste', 'Orthodontie', 'j.petit@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (5, 2, 'Robert', 'Nicolas', 'Hygieniste', NULL, 'n.robert@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (8, 2, 'Dubois', 'Sarah', 'Assistant', NULL, 's.dubois@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (4, 3, 'Richard', 'Emma', 'Dentiste', 'Implantologie', 'e.richard@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (9, 3, 'Moreau', 'Lucas', 'Assistant', NULL, 'l.moreau@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (10, 3, 'Faure', 'Camille', 'Dentiste', 'Omnipratique', 'c.faure@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (11, 4, 'Girard', 'Paul', 'Dentiste', 'Parodontologie', 'p.girard@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (12, 4, 'Bonnet', 'Lisa', 'Assistant', NULL, 'l.bonnet@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (13, 4, 'Blanc', 'Hugo', 'Praticien Externe', 'Anesthésiste', 'h.blanc@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (14, 5, 'Roux', 'Gabriel', 'Dentiste', 'Omnipratique', 'g.roux@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (15, 5, 'Vincent', 'Chloe', 'Assistant', NULL, 'c.vincent@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (16, 5, 'Andre', 'Leo', 'Hygieniste', NULL, 'l.andre@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (17, 6, 'Lefebvre', 'Marc', 'Dentiste', 'Endodontie', 'm.lefebvre@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (18, 6, 'Mercier', 'Manon', 'Assistant', NULL, 'manon.m@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (19, 6, 'Dupont', 'Jean', 'Praticien Externe', 'Chirurgie Maxillo', 'j.dupont@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (20, 7, 'Guerin', 'Arthur', 'Dentiste', 'Pédodontie', 'a.guerin@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (21, 7, 'Fontaine', 'Lea', 'Assistant', NULL, 'l.fontaine@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (22, 8, 'Chevalier', 'Nathan', 'Dentiste', 'Omnipratique', 'n.chevalier@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (23, 8, 'Gauthier', 'Zoe', 'Assistant', NULL, 'z.gauthier@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (24, 8, 'Perrin', 'Adam', 'Dentiste', 'Orthodontie', 'a.perrin@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (25, 9, 'Robin', 'Louis', 'Dentiste', 'Esthétique', 'l.robin@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (26, 9, 'Masson', 'Eva', 'Assistant', NULL, 'e.masson@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (27, 9, 'Sanchez', 'Ines', 'Administratif', 'Secrétaire', 'i.sanchez@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (28, 10, 'Muller', 'Theo', 'Dentiste', 'Omnipratique', 't.muller@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (29, 10, 'Lambert', 'Jade', 'Assistant', NULL, 'j.lambert@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (30, 11, 'Marchand', 'Axel', 'Dentiste', 'Omnipratique', 'a.marchand@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (31, 11, 'Duval', 'Lola', 'Assistant', NULL, 'l.duval@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (32, 1, 'Vidal', 'Jules', 'Dentiste', 'Omnipratique', 'j.vidal@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (33, 1, 'Renaud', 'Anna', 'Administratif', 'Réception', 'a.renaud@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (34, 3, 'Lemoine', 'Tom', 'Hygieniste', NULL, 't.lemoine@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (35, 5, 'Picard', 'Mael', 'Dentiste', 'Implantologie', 'm.picard@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (36, 5, 'Leclerc', 'Rose', 'Assistant', NULL, 'r.leclerc@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (37, 6, 'Aubry', 'Raphael', 'Dentiste', 'Parodontologie', 'r.aubry@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (38, 7, 'Hubert', 'Mila', 'Hygieniste', NULL, 'm.hubert@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (39, 8, 'Baron', 'Sacha', 'Assistant', NULL, 's.baron@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (40, 9, 'Tessier', 'Louise', 'Dentiste', 'Omnipratique', 'l.tessier@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (41, 10, 'Prevost', 'Noe', 'Praticien Externe', 'Anesthésiste', 'n.prevost@d.fr');
INSERT INTO Personnel (id_personnel, id_franchise, nom, prenom, role, specialite, email) VALUES (42, 11, 'Roy', 'Lina', 'Hygieniste', NULL, 'l.roy@d.fr');



-- ==============================================================================
-- FOURNISSEURS (3 lignes)
-- ==============================================================================
INSERT INTO Fournisseurs (id_fournisseur, nom_fournisseur, contact, telephone, ville) VALUES (1,'Nord Dentisto','Mme Dupont','0123456789','Lille');
INSERT INTO Fournisseurs (id_fournisseur, nom_fournisseur, contact, telephone, ville) VALUES (2,'Grand Ouest Dentition','Mr Desousa','0135678909','La Rochelle');
INSERT INTO Fournisseurs (id_fournisseur, nom_fournisseur, contact, telephone, ville) VALUES (3,'Dento SUD','Mr De La Fontaine','0135678909','Nice');


-- ==============================================================================
-- PATIENTS (50 lignes)
-- ==============================================================================
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (1, 1, 'Dubois', 'Jean', TO_DATE('1950-01-01', 'YYYY-MM-DD'), 'HOMME', '12 Rue de la Paix', 'Niort', '75001', '0601010101', 'jean.dubois@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (2, 1, 'Durand', 'Marie', TO_DATE('2015-06-15', 'YYYY-MM-DD'), 'FEMME', '8 Avenue Victor Hugo', 'Niort', '75016', '0602020202', 'parent.durand@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (3, 2, 'Leroy', 'Paul', TO_DATE('1990-11-20', 'YYYY-MM-DD'), 'HOMME', '45 Boulevard Saint-Germain', 'Paris', '75005', '0603030303', 'paul.leroy@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (4, 3, 'Moreau', 'Lucie', TO_DATE('1985-03-30', 'YYYY-MM-DD'), 'FEMME', '10 Rue de la République', 'Lyon', '69001', '0604040404', 'lucie.moreau@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (5, 3, 'Simon', 'Hugo', TO_DATE('2010-12-12', 'YYYY-MM-DD'), 'HOMME', '22 Cours Lafayette', 'Lyon', '69003', '0605050505', 'parent.simon@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (6, 1, 'Petit', 'Thomas', TO_DATE('1982-05-10', 'YYYY-MM-DD'), 'HOMME', '5 Rue de Rivoli', 'Niort', '75004', '0606060606', 'thomas.petit@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (7, 1, 'Roux', 'Emma', TO_DATE('1995-09-23', 'YYYY-MM-DD'), 'FEMME', '33 Rue Monge', 'Niort', '75005', '0607070707', 'emma.roux@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (8, 1, 'Blanc', 'Lucas', TO_DATE('1978-11-12', 'YYYY-MM-DD'), 'HOMME', '18 Avenue Montaigne', 'Niort', '75008', '0608080808', 'lucas.blanc@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (9, 1, 'Garnier', 'Chloé', TO_DATE('2001-03-04', 'YYYY-MM-DD'), 'FEMME', '9 Rue de la Pompe', 'Niort', '75116', '0609090909', 'chloe.garnier@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (10, 1, 'Faure', 'Nathan', TO_DATE('2019-07-30', 'YYYY-MM-DD'), 'HOMME', '14 Boulevard Voltaire', 'Niort', '75011', '0610101010', 'parent.faure@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (11, 1, 'Legrand', 'Léa', TO_DATE('1960-02-15', 'YYYY-MM-DD'), 'FEMME', '67 Rue de Belleville', 'Niort', '75019', '0611111111', 'lea.legrand@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (12, 1, 'Gauthier', 'Enzo', TO_DATE('1988-12-01', 'YYYY-MM-DD'), 'HOMME', '12 Rue des Rosiers', 'Niort', '75004', '0612121212', 'enzo.gauthier@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (13, 1, 'Perrin', 'Manon', TO_DATE('1992-06-18', 'YYYY-MM-DD'), 'FEMME', '55 Rue de Tolbiac', 'Niort', '75013', '0613131313', 'manon.perrin@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (14, 1, 'Robin', 'Gabriel', TO_DATE('2010-10-10', 'YYYY-MM-DD'), 'HOMME', '4 Place de la République', 'Niort', '75011', '0614141414', 'parent.robin@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (15, 1, 'Clement', 'Jade', TO_DATE('1985-04-22', 'YYYY-MM-DD'), 'FEMME', '78 Avenue de Flandre', 'Niort', '75019', '0615151515', 'jade.clement@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (16, 1, 'Morin', 'Louis', TO_DATE('1955-08-05', 'YYYY-MM-DD'), 'HOMME', '23 Rue de la Convention', 'Niort', '75015', '0616161616', 'louis.morin@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (17, 1, 'Nicolas', 'Louise', TO_DATE('1970-01-25', 'YYYY-MM-DD'), 'FEMME', '89 Rue de Vaugirard', 'Niort', '75015', '0617171717', 'louise.nicolas@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (18, 1, 'Henry', 'Arthur', TO_DATE('2016-11-11', 'YYYY-MM-DD'), 'HOMME', '34 Rue Damrémont', 'Niort', '75018', '0618181818', 'parent.henry@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (19, 1, 'Roussel', 'Alice', TO_DATE('1999-05-05', 'YYYY-MM-DD'), 'FEMME', '21 Rue d Alesia', 'Niort', '75014', '0619191919', 'alice.roussel@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (20, 1, 'Mathieu', 'Raphaël', TO_DATE('1983-09-09', 'YYYY-MM-DD'), 'HOMME', '90 Rue de Rennes', 'Niort', '75006', '0620202020', 'raphael.mathieu@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (21, 1, 'Guerin', 'Lina', TO_DATE('1965-03-14', 'YYYY-MM-DD'), 'FEMME', '15 Rue Oberkampf', 'Niort', '75011', '0621212121', 'lina.guerin@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (22, 1, 'Boyer', 'Jules', TO_DATE('2005-07-20', 'YYYY-MM-DD'), 'HOMME', '44 Rue des Archives', 'Niort', '75003', '0622222222', 'jules.boyer@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (23, 1, 'Andre', 'Mila', TO_DATE('1991-02-28', 'YYYY-MM-DD'), 'FEMME', '76 Avenue des Ternes', 'Niort', '75017', '0623232323', 'mila.andre@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (24, 1, 'Roche', 'Hugo', TO_DATE('1975-06-30', 'YYYY-MM-DD'), 'HOMME', '50 Rue de la Roquette', 'Niort', '75011', '0624242424', 'hugo.roche@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (25, 1, 'Roy', 'Rose', TO_DATE('2012-12-12', 'YYYY-MM-DD'), 'FEMME', '11 Rue Cler', 'Niort', '75007', '0625252525', 'parent.roy@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (26, 2, 'Noel', 'Leo', TO_DATE('1990-01-01', 'YYYY-MM-DD'), 'HOMME', '33 Boulevard Masséna', 'Paris', '75013', '0626262626', 'leo.noel@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (27, 2, 'Meyer', 'Zoé', TO_DATE('1986-04-15', 'YYYY-MM-DD'), 'FEMME', '8 Avenue d Italie', 'Paris', '75013', '0627272727', 'zoe.meyer@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (28, 2, 'Lucas', 'Paul', TO_DATE('2000-08-20', 'YYYY-MM-DD'), 'HOMME', '5 Rue Bobillot', 'Paris', '75013', '0628282828', 'paul.lucas@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (29, 3, 'Chevalier', 'Anna', TO_DATE('1958-11-05', 'YYYY-MM-DD'), 'FEMME', '12 Rue Garibaldi', 'Lyon', '69006', '0629292929', 'anna.chevalier@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (30, 3, 'Blanc', 'Tom', TO_DATE('2014-02-10', 'YYYY-MM-DD'), 'HOMME', '5 Place Bellecour', 'Lyon', '69002', '0630303030', 'parent.blanc@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (31, 3, 'Francois', 'Eva', TO_DATE('1993-07-25', 'YYYY-MM-DD'), 'FEMME', '45 Rue de la République', 'Lyon', '69002', '0631313131', 'eva.francois@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (32, 4, 'David', 'Maxime', TO_DATE('1980-09-12', 'YYYY-MM-DD'), 'HOMME', '10 Quai Saint-Antoine', 'Lyon', '69002', '0632323232', 'maxime.david@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (33, 4, 'Bertrand', 'Inès', TO_DATE('1972-12-30', 'YYYY-MM-DD'), 'FEMME', '22 Rue Victor Hugo', 'Lyon', '69002', '0633333333', 'ines.bertrand@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (34, 5, 'Marchand', 'Théo', TO_DATE('1998-05-18', 'YYYY-MM-DD'), 'HOMME', '8 Quai du Port', 'Marseille', '13002', '0634343434', 'theo.marchand@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (35, 5, 'Dupuy', 'Lola', TO_DATE('2002-10-05', 'YYYY-MM-DD'), 'FEMME', '15 Rue de Rome', 'Marseille', '13001', '0635353535', 'lola.dupuy@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (36, 6, 'Renard', 'Antoine', TO_DATE('1968-03-22', 'YYYY-MM-DD'), 'HOMME', '20 Rue Sainte-Catherine', 'Bordeaux', '33000', '0636363636', 'antoine.renard@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (37, 6, 'Brun', 'Sarah', TO_DATE('1989-11-01', 'YYYY-MM-DD'), 'FEMME', '12 Place de la Bourse', 'Bordeaux', '33000', '0637373737', 'sarah.brun@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (38, 7, 'Vallet', 'Kevin', TO_DATE('1995-06-10', 'YYYY-MM-DD'), 'HOMME', '8 Place du Général de Gaulle', 'Lille', '59000', '0638383838', 'kevin.vallet@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (39, 7, 'Lemoine', 'Camille', TO_DATE('1992-04-04', 'YYYY-MM-DD'), 'FEMME', '44 Rue Faidherbe', 'Lille', '59000', '0639393939', 'camille.lemoine@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (40, 8, 'Picard', 'Alex', TO_DATE('1977-08-15', 'YYYY-MM-DD'), 'HOMME', '12 Place du Capitole', 'Toulouse', '31000', '0640404040', 'alex.picard@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (41, 8, 'Giraud', 'Maëlys', TO_DATE('2011-01-20', 'YYYY-MM-DD'), 'FEMME', '5 Rue Saint-Rome', 'Toulouse', '31000', '0641414141', 'parent.giraud@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (42, 9, 'Guillaume', 'Romain', TO_DATE('1984-12-05', 'YYYY-MM-DD'), 'HOMME', '50 Promenade des Anglais', 'Nice', '06000', '0642424242', 'romain.guillaume@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (43, 9, 'Leclerc', 'Julia', TO_DATE('1996-09-09', 'YYYY-MM-DD'), 'FEMME', '15 Avenue Jean Médecin', 'Nice', '06000', '0643434343', 'julia.leclerc@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (44, 10, 'Laporte', 'Florian', TO_DATE('1991-05-25', 'YYYY-MM-DD'), 'HOMME', '4 Rue Crébillon', 'Nantes', '44000', '0644444444', 'florian.laporte@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (45, 10, 'Caron', 'Elise', TO_DATE('1979-10-30', 'YYYY-MM-DD'), 'FEMME', '10 Place Royale', 'Nantes', '44000', '0645454545', 'elise.caron@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (46, 11, 'Vidal', 'Sébastien', TO_DATE('1965-02-14', 'YYYY-MM-DD'), 'HOMME', '22 Place Kléber', 'Strasbourg', '67000', '0646464646', 'sebastien.vidal@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (47, 11, 'Moulin', 'Clara', TO_DATE('2008-07-07', 'YYYY-MM-DD'), 'FEMME', '8 Rue des Grandes Arcades', 'Strasbourg', '67000', '0647474747', 'parent.moulin@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (48, 1, 'Sanchez', 'Diego', TO_DATE('1988-03-18', 'YYYY-MM-DD'), 'HOMME', '77 Rue de Rivoli', 'Niort', '75001', '0648484848', 'diego.sanchez@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (49, 1, 'Dupont', 'Amélie', TO_DATE('1994-06-22', 'YYYY-MM-DD'), 'FEMME', '10 Rue de la Paix', 'Niort', '75002', '0649494949', 'amelie.dupont@email.fr');
INSERT INTO Patients (id_patient, id_franchise_principale, nom, prenom, date_naissance, sexe, adresse, ville, cp, telephone, email) VALUES (50, 1, 'Lefevre', 'Pierre', TO_DATE('1952-11-11', 'YYYY-MM-DD'), 'HOMME', '55 Avenue Victor Hugo', 'Niort', '75116', '0650505050', 'pierre.lefevre@email.fr');

-- ==============================================================================
-- DOSSIERS PATIENTS (50 lignes)
-- ==============================================================================
BEGIN
    FOR i IN 1..29 LOOP
        INSERT INTO Dossiers_Patients (id_patient, etat, notes_generales) 
        VALUES (i, CASE MOD(i, 5) WHEN 0 THEN 'Fermé' ELSE 'Ouvert' END, 'Dossier créé automatiquement '||i);
    END LOOP;
END;
/
BEGIN
    FOR i IN 30..50 LOOP
        INSERT INTO Dossiers_Patients (id_patient, date_creation, etat, notes_generales) 
        VALUES (i, DATE '2024-01-01' + trunc(dbms_random.value(0,365)), CASE MOD(i, 5) WHEN 0 THEN 'Fermé' ELSE 'Ouvert' END, 'Dossier créé automatiquement '||i);
    END LOOP;
END;
/

-- ==============================================================================
-- TRAITEMENTS (50 lignes)
-- ==============================================================================
DECLARE
    v_date_debut DATE;
    v_duree_traitement NUMBER;
BEGIN
    FOR i IN 1..50 LOOP
        -- Générer une date de début aléatoire
        v_date_debut := DATE '2024-01-01' + trunc(dbms_random.value(0,300));
        -- Générer une durée de traitement entre 7 et 90 jours
        v_duree_traitement := trunc(dbms_random.value(7,91));
        
        INSERT INTO Traitements (id_traitement, id_dossier, details_traitement, date_debut, date_fin, cout_total_estime) 
        VALUES (i, i, 'Traitement Global n°'||i, v_date_debut, v_date_debut + v_duree_traitement, 100.00 * i);
    END LOOP;
END;
/

-- ==============================================================================
-- ACTES MEDICAUX (60 lignes )
-- ==============================================================================
INSERT INTO Actes_Medicaux (id_acte, id_traitement, id_dossier, id_praticien, type_acte, description_acte, montant, date_acte) VALUES (1, 1, 1, 1, 'Consultation', 'Bilan', 25.00, TO_DATE('2024-01-10', 'YYYY-MM-DD'));
INSERT INTO Actes_Medicaux (id_acte, id_traitement, id_dossier, id_praticien, type_acte, description_acte, montant, date_acte) VALUES (2, 1, 1, 1, 'Soins', 'Détartrage', 45.00, TO_DATE('2024-01-10', 'YYYY-MM-DD'));
INSERT INTO Actes_Medicaux (id_acte, id_traitement, id_dossier, id_praticien, type_acte, description_acte, montant, date_acte) VALUES (3, 2, 2, 3, 'Orthodontie', 'Bagues', 600.00, TO_DATE('2024-02-15', 'YYYY-MM-DD'));
INSERT INTO Actes_Medicaux (id_acte, id_traitement, id_dossier, id_praticien, type_acte, description_acte, montant, date_acte) VALUES (4, 3, 3, 1, 'Chirurgie', 'Extraction', 80.00, TO_DATE('2024-03-20', 'YYYY-MM-DD'));
INSERT INTO Actes_Medicaux (id_acte, id_traitement, id_dossier, id_praticien, type_acte, description_acte, montant, date_acte) VALUES (5, 4, 4, 5, 'Implantologie', 'Pose Implant', 900.00, TO_DATE('2025-02-05', 'YYYY-MM-DD'));

BEGIN
    FOR i IN 6..60 LOOP
        INSERT INTO Actes_Medicaux (id_acte, id_traitement, id_dossier, id_praticien, type_acte, description_acte, montant, date_acte) 
        VALUES (i, MOD(i, 40)+1, MOD(i, 40)+1, MOD(i, 10)+1, 
                CASE MOD(i, 5) WHEN 0 THEN 'Soins' WHEN 1 THEN 'Chirurgie' WHEN 2 THEN 'Radio' WHEN 3 THEN 'Orthodontie' ELSE 'Consultation' END,
                'Acte automatique '||i, 
                25.00 + MOD(i, 100), -- Montants variés
                TO_DATE('2024-01-01', 'YYYY-MM-DD') + trunc(dbms_random.value(0,700))); -- Dates aléatoires en 2024 et 2025 (max novembre)
    END LOOP;
END;
/

-- ==============================================================================
-- PRODUITS DENTAIRES (40 lignes)
-- ==============================================================================
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (1, 1, 'Septanest 4%', 'Anesthésique local avec adrénaline 1/100000', 50, 20);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (2, 1, 'Gants Nitrile M', 'Boîte de 100 gants non poudrés bleu', 8, 5);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (3, 1, 'Composite Filtek A2', 'Seringue composite universel teinte A2', 15, 3);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (4, 1, 'Masques FFP2', 'Boîte de 50 masques protection respiratoire', 30, 10);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (5, 2, 'Septanest 4%', 'Anesthésique local avec adrénaline 1/100000', 45, 20);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (6, 2, 'Gants Nitrile L', 'Boîte de 100 gants non poudrés bleu', 20, 5);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (7, 2, 'Composite Filtek A3', 'Seringue composite universel teinte A3', 4, 3);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (8, 2, 'Kit Implantologie', 'Set stérile complet pour pose implant', 10, 5);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (9, 3, 'Bavoirs Jetables', 'Rouleau de 80 bavoirs plastifiés verts', 100, 15);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (10, 3, 'Canules Aspiration', 'Sachet de 100 canules usage unique', 50, 10);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (11, 3, 'Ciment Verre Ionomère', 'Coffret ciment de scellement définitif', 2, 2);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (12, 3, 'Gants Nitrile M', 'Boîte de 100 gants non poudrés bleu', 25, 5);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (13, 4, 'Lidocaïne Spray', 'Anesthésique de surface 50ml', 5, 2);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (14, 4, 'Adhésif Scotchbond', 'Flacon adhésif universel 5ml', 8, 3);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (15, 4, 'Fraises Diamantées', 'Set de 5 fraises boule turbine', 12, 5);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (16, 4, 'Masques Chirurgicaux', 'Boîte de 50 masques type IIR', 60, 20);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (17, 5, 'Alginate Chromatique', 'Sachet 500g pour empreintes', 20, 5);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (18, 5, 'Plâtre Dur', 'Sac de 5kg plâtre type 3', 3, 2);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (19, 5, 'Gants Latex S', 'Boîte de 100 gants poudrés', 15, 5);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (20, 5, 'Composite Filtek A2', 'Seringue composite universel teinte A2', 10, 3);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (21, 6, 'Limes K 25mm', 'Boîte de 6 limes manuelles endodontie', 30, 10);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (22, 6, 'Cônes Papier', 'Boîte assortiment pointes papier stériles', 40, 5);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (23, 6, 'Hypochlorite Sodium', 'Bidon 1L pour irrigation canalaire', 10, 2);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (24, 6, 'Gutta Percha', 'Boîte de pointes pour obturation', 25, 5);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (25, 7, 'Cotons Salivaires', 'Sachet de 1000 rouleaux de coton', 50, 10);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (26, 7, 'Matrice Métallique', 'Rouleau bande matrice acier', 15, 3);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (27, 7, 'Coins de Bois', 'Boîte assortiment coins interdentaires', 20, 5);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (28, 7, 'Digue Dentaire', 'Feuilles de digue latex vert moyen', 10, 2);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (29, 8, 'Gel Mordançage', 'Seringue acide phosphorique 37%', 18, 4);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (30, 8, 'Composite Filtek A2', 'Seringue composite universel teinte A2', 2, 5);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (31, 8, 'Gants Nitrile M', 'Boîte de 100 gants non poudrés bleu', 40, 5);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (32, 9, 'Produit Blanchiment', 'Kit blanchiment ambulatoire 16%', 5, 2);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (33, 9, 'Ecarteur Labial', 'Ecarteur souple usage unique (lot 10)', 15, 5);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (34, 9, 'Pâte Polissage', 'Pot prophylaxie grain moyen menthe', 8, 3);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (35, 10, 'Sachets Stérilisation', 'Gaine 200mm x 200m auto-collante', 12, 4);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (36, 10, 'Test Bowie Dick', 'Test pénétration vapeur autoclave', 20, 5);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (37, 10, 'Anesthésique Sans Adré', 'Mépivacaïne 3% sans vasoconstricteur', 20, 10);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (38, 11, 'Septanest 4%', 'Anesthésique local avec adrénaline 1/100000', 60, 20);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (39, 11, 'Gants Nitrile M', 'Boîte de 100 gants non poudrés bleu', 10, 5);
INSERT INTO Produits_Dentaires (id_produit, id_franchise, nom_produit, description, quantite_stock, seuil_alerte) VALUES (40, 11, 'Composite Filtek A3', 'Seringue composite universel teinte A3', 8, 3);

-- ==============================================================================
-- COMMANDES et LIGNES COMMANDE (40 lignes)
-- ==============================================================================
BEGIN
    FOR i IN 1..40 LOOP
        -- Commande
        INSERT INTO Commandes (id_commande, id_fournisseur, id_franchise, date_commande, statut) 
        -- CORRECTION ICI : MOD(i, 3)+1 assure qu'on reste sur les ID 1, 2 ou 3
        VALUES (i, MOD(i, 3)+1, MOD(i, 10)+1, TO_DATE('2024-01-01', 'YYYY-MM-DD') + trunc(dbms_random.value(0,700)), 'Livrée');
        
        -- Ligne de commande associée (1 pour 1 pour simplifier le script)
        INSERT INTO Lignes_Commande (id_ligne, id_commande, id_produit, quantite, prix_unitaire) 
        VALUES (i, i, MOD(i, 40)+1, 10 + MOD(i, 5), 5.00 + MOD(i, 10));
    END LOOP;
END;
/

-- ==============================================================================
-- PAIEMENTS (20 lignes)
-- ==============================================================================
INSERT INTO Paiements (id_patient, id_acte, id_traitement, montant, date_paiement, moyen_paiement) VALUES (1, 12, NULL, 45.00, TO_DATE('2024-01-15', 'YYYY-MM-DD'), 'CB');
INSERT INTO Paiements (id_patient, id_acte, id_traitement, montant, date_paiement, moyen_paiement) VALUES (2, NULL, 5, 500.00, TO_DATE('2024-02-10', 'YYYY-MM-DD'), 'Virement bancaire');
INSERT INTO Paiements (id_patient, id_acte, id_traitement, montant, date_paiement, moyen_paiement) VALUES (3, 45, NULL, 23.00, TO_DATE('2024-03-05', 'YYYY-MM-DD'), 'Espèces');
INSERT INTO Paiements (id_patient, id_acte, id_traitement, montant, date_paiement, moyen_paiement) VALUES (4, NULL, 22, 1200.00, TO_DATE('2024-01-20', 'YYYY-MM-DD'), 'Chèque');
INSERT INTO Paiements (id_patient, id_acte, id_traitement, montant, date_paiement, moyen_paiement) VALUES (5, 8, NULL, 75.50, TO_DATE('2024-04-12', 'YYYY-MM-DD'), 'CB');
INSERT INTO Paiements (id_patient, id_acte, id_traitement, montant, date_paiement, moyen_paiement) VALUES (6, 33, 33, 150.00, TO_DATE('2024-05-18', 'YYYY-MM-DD'), 'CB');
INSERT INTO Paiements (id_patient, id_acte, id_traitement, montant, date_paiement, moyen_paiement) VALUES (7, NULL, 1, 600.00, TO_DATE('2024-06-22', 'YYYY-MM-DD'), 'Virement bancaire');
INSERT INTO Paiements (id_patient, id_acte, id_traitement, montant, date_paiement, moyen_paiement) VALUES (8, 19, NULL, 23.00, TO_DATE('2024-07-30', 'YYYY-MM-DD'), 'Espèces');
INSERT INTO Paiements (id_patient, id_acte, id_traitement, montant, date_paiement, moyen_paiement) VALUES (9, 50, NULL, 90.00, TO_DATE('2024-08-14', 'YYYY-MM-DD'), 'CB');
INSERT INTO Paiements (id_patient, id_acte, id_traitement, montant, date_paiement, moyen_paiement) VALUES (10, NULL, 44, 350.00, TO_DATE('2024-09-01', 'YYYY-MM-DD'), 'Chèque');
INSERT INTO Paiements (id_patient, id_acte, id_traitement, montant, date_paiement, moyen_paiement) VALUES (11, 2, NULL, 120.00, TO_DATE('2024-10-10', 'YYYY-MM-DD'), 'CB');
INSERT INTO Paiements (id_patient, id_acte, id_traitement, montant, date_paiement, moyen_paiement) VALUES (12, NULL, 15, 1500.00, TO_DATE('2024-11-05', 'YYYY-MM-DD'), 'Virement bancaire');
INSERT INTO Paiements (id_patient, id_acte, id_traitement, montant, date_paiement, moyen_paiement) VALUES (13, 28, NULL, 65.00, TO_DATE('2024-12-20', 'YYYY-MM-DD'), 'CB');
INSERT INTO Paiements (id_patient, id_acte, id_traitement, montant, date_paiement, moyen_paiement) VALUES (14, 7, NULL, 23.00, TO_DATE('2025-01-08', 'YYYY-MM-DD'), 'Espèces');
INSERT INTO Paiements (id_patient, id_acte, id_traitement, montant, date_paiement, moyen_paiement) VALUES (15, NULL, 30, 450.00, TO_DATE('2025-01-15', 'YYYY-MM-DD'), 'Chèque');
INSERT INTO Paiements (id_patient, id_acte, id_traitement, montant, date_paiement, moyen_paiement) VALUES (16, 41, NULL, 55.00, TO_DATE('2025-02-01', 'YYYY-MM-DD'), 'CB');
INSERT INTO Paiements (id_patient, id_acte, id_traitement, montant, date_paiement, moyen_paiement) VALUES (17, 14, 14, 80.00, TO_DATE('2025-02-12', 'YYYY-MM-DD'), 'CB');
INSERT INTO Paiements (id_patient, id_acte, id_traitement, montant, date_paiement, moyen_paiement) VALUES (18, NULL, 49, 800.00, TO_DATE('2025-02-28', 'YYYY-MM-DD'), 'Virement bancaire');
INSERT INTO Paiements (id_patient, id_acte, id_traitement, montant, date_paiement, moyen_paiement) VALUES (19, 22, NULL, 35.00, TO_DATE('2025-03-01', 'YYYY-MM-DD'), 'Espèces');
INSERT INTO Paiements (id_patient, id_acte, id_traitement, montant, date_paiement, moyen_paiement) VALUES (20, NULL, 3, 250.00, TO_DATE('2025-03-10', 'YYYY-MM-DD'), 'Chèque');

-- ==============================================================================
-- ETAT BUCCAL : DENTS, ETAT DENTS HISTORIQUE, ANOMALIES, RESTAURATIONS (50 lignes)
-- ==============================================================================
BEGIN
    FOR i IN 1..50 LOOP
        INSERT INTO Dents (id_dent, id_patient, code_fdi) 
        VALUES (i, MOD(i, 40)+1, 11 + MOD(i, 30)); 

        INSERT INTO Etat_Dents_Historique (id_etat, id_dent, date_observation, type_etat, detail_etat) 
        VALUES (i, i, SYSDATE - MOD(i, 100), 
                CASE MOD(i, 2) WHEN 0 THEN 'Anomalie' ELSE 'Restauration' END, 
                'Observation n°'||i);

        IF MOD(i, 2) = 0 THEN
            INSERT INTO Anomalies (id_anomalie, id_etat, type_anomalie, gravite_stade) 
            VALUES (i, i, CASE 
                WHEN dbms_random.value(1, 100) < 50 THEN 'Carie'
                WHEN dbms_random.value(1, 100) < 50 THEN 'Fracture'
                ELSE 'Infection' END, 'Moyen');
        ELSE
            INSERT INTO Restaurations (id_restauration, id_etat, type_restauration, materiau_utilise) 
            VALUES (i, i, CASE MOD(i, 3) WHEN 0 THEN 'Couronne' WHEN 1 THEN 'Implant' ELSE 'Amalgame' END, 'Céramique');
        END IF;
    END LOOP;
END;
/

-- Insertion supplémentaire pour 'Simon' pour les requêtes SELECT
INSERT INTO Dents (id_dent, id_patient, code_fdi) VALUES (100, 5, 21); 
INSERT INTO Dents (id_dent, id_patient, code_fdi) VALUES (101, 5, 22); 
INSERT INTO Etat_Dents_Historique (id_etat, id_dent, date_observation, type_etat, detail_etat) 
        VALUES (100, 100, CURRENT_DATE, 'Anomalie','Observation n°100');
INSERT INTO Etat_Dents_Historique (id_etat, id_dent, date_observation, type_etat, detail_etat) 
        VALUES (101, 101, CURRENT_DATE, 'Restauration','Observation n°101');
INSERT INTO Anomalies (id_anomalie, id_etat, type_anomalie, gravite_stade) VALUES (100,100, 'Carie', 'Infection');
INSERT INTO Restaurations (id_restauration, id_etat, type_restauration, materiau_utilise) VALUES (101,101, 'Couronne', 'Céramique');

-- ==============================================================================
-- EQUIPEMENTS (38 lignes)
-- ==============================================================================
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (1, 1, 'Fauteuil Dentaire A-Dec 500', TO_DATE('2020-05-15', 'YYYY-MM-DD'), 'Fonctionnel', TO_DATE('2024-05-15', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (2, 1, 'Radio Panoramique Carestream CS 8100', TO_DATE('2019-11-20', 'YYYY-MM-DD'), 'Fonctionnel', TO_DATE('2024-11-20', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (3, 1, 'Autoclave Classe B WandH Lisa', TO_DATE('2021-03-10', 'YYYY-MM-DD'), 'Fonctionnel', TO_DATE('2025-01-10', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (4, 2, 'Fauteuil Chirurgical Planmeca Compact', TO_DATE('2022-01-05', 'YYYY-MM-DD'), 'Fonctionnel', TO_DATE('2025-01-05', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (5, 2, 'Cone Beam (CBCT) Dentsply Sirona', TO_DATE('2022-02-15', 'YYYY-MM-DD'), 'Fonctionnel', TO_DATE('2024-08-15', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (6, 2, 'Usineuse CEREC Primemill', TO_DATE('2023-06-20', 'YYYY-MM-DD'), 'Maintenance', TO_DATE('2025-02-28', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (7, 2, 'Autoclave Melag Vacuklav', TO_DATE('2022-01-10', 'YYYY-MM-DD'), 'Fonctionnel', TO_DATE('2025-01-15', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (8, 3, 'Fauteuil Stern Weber S380', TO_DATE('2018-09-12', 'YYYY-MM-DD'), 'Fonctionnel', TO_DATE('2024-09-12', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (9, 3, 'Radio Panoramique Vatech PaX-i', TO_DATE('2019-04-04', 'YYYY-MM-DD'), 'Fonctionnel', TO_DATE('2024-10-01', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (10, 3, 'Autoclave Euronda E9', TO_DATE('2020-08-30', 'YYYY-MM-DD'), 'En panne', TO_DATE('2024-12-15', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (11, 4, 'Fauteuil Kavo Estetica E50', TO_DATE('2021-12-01', 'YYYY-MM-DD'), 'Fonctionnel', TO_DATE('2024-12-01', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (12, 4, 'Scanner Intra-oral Trios 3Shape', TO_DATE('2023-02-14', 'YYYY-MM-DD'), 'Fonctionnel', TO_DATE('2025-01-20', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (13, 4, 'Thermo-désinfecteur Miele', TO_DATE('2021-11-10', 'YYYY-MM-DD'), 'Fonctionnel', TO_DATE('2024-11-10', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (14, 5, 'Fauteuil Belmont Clesta II', TO_DATE('2017-06-25', 'YYYY-MM-DD'), 'Maintenance', TO_DATE('2025-02-25', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (15, 5, 'Radio Panoramique Owandy I-Max', TO_DATE('2020-01-15', 'YYYY-MM-DD'), 'Fonctionnel', TO_DATE('2024-06-15', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (16, 5, 'Autoclave WandH Lina', TO_DATE('2019-05-05', 'YYYY-MM-DD'), 'Fonctionnel', TO_DATE('2024-12-20', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (17, 6, 'Fauteuil Anthos A3 Plus', TO_DATE('2021-07-30', 'YYYY-MM-DD'), 'Fonctionnel', TO_DATE('2024-07-30', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (18, 6, 'Microscope Zeiss Extaro 300', TO_DATE('2022-09-10', 'YYYY-MM-DD'), 'Fonctionnel', TO_DATE('2024-09-10', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (19, 6, 'Autoclave Melag Pro-Class', TO_DATE('2021-08-15', 'YYYY-MM-DD'), 'Fonctionnel', TO_DATE('2024-08-15', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (20, 7, 'Fauteuil Sirona Intego', TO_DATE('2023-01-10', 'YYYY-MM-DD'), 'Fonctionnel', TO_DATE('2025-01-10', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (21, 7, 'Radio Murale Kodak 2200', TO_DATE('2018-03-20', 'YYYY-MM-DD'), 'Hors service', TO_DATE('2023-12-01', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (22, 7, 'Autoclave Tuttnauer 2540', TO_DATE('2020-11-25', 'YYYY-MM-DD'), 'Fonctionnel', TO_DATE('2024-11-25', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (23, 8, 'Fauteuil Morita Soaric', TO_DATE('2019-02-14', 'YYYY-MM-DD'), 'Fonctionnel', TO_DATE('2024-02-14', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (24, 8, 'Radio Panoramique Acteon X-Mind', TO_DATE('2021-05-22', 'YYYY-MM-DD'), 'Fonctionnel', TO_DATE('2024-05-22', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (25, 8, 'Moteur Endodontie X-Smart', TO_DATE('2022-10-10', 'YYYY-MM-DD'), 'Fonctionnel', TO_DATE('2025-02-01', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (26, 9, 'Fauteuil A-Dec 300', TO_DATE('2020-06-30', 'YYYY-MM-DD'), 'Fonctionnel', TO_DATE('2024-06-30', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (27, 9, 'Lampe de blanchiment Philips Zoom', TO_DATE('2023-04-18', 'YYYY-MM-DD'), 'Fonctionnel', TO_DATE('2025-01-05', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (28, 9, 'Autoclave WandH Lisa', TO_DATE('2020-07-15', 'YYYY-MM-DD'), 'Fonctionnel', TO_DATE('2024-07-15', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (29, 10, 'Fauteuil Planmeca ProStyle', TO_DATE('2022-09-09', 'YYYY-MM-DD'), 'Fonctionnel', TO_DATE('2024-09-09', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (30, 10, 'Radio Panoramique Planmeca ProMax', TO_DATE('2022-10-01', 'YYYY-MM-DD'), 'Maintenance', TO_DATE('2025-03-01', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (31, 10, 'Compresseur Durr Dental', TO_DATE('2021-01-20', 'YYYY-MM-DD'), 'Fonctionnel', TO_DATE('2024-12-10', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (32, 11, 'Fauteuil Kavo Primus', TO_DATE('2018-11-11', 'YYYY-MM-DD'), 'Fonctionnel', TO_DATE('2024-11-11', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (33, 11, 'Scanner Intra-oral Medit i700', TO_DATE('2023-08-08', 'YYYY-MM-DD'), 'Fonctionnel', TO_DATE('2025-02-15', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (34, 11, 'Autoclave DAC Universal', TO_DATE('2019-12-05', 'YYYY-MM-DD'), 'En panne', TO_DATE('2025-01-10', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (35, 1, 'Fauteuil Secondaire A-Dec 300', TO_DATE('2021-05-15', 'YYYY-MM-DD'), 'Fonctionnel', TO_DATE('2024-05-15', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (36, 2, 'Fauteuil Prophylaxie Kavo', TO_DATE('2023-01-20', 'YYYY-MM-DD'), 'Fonctionnel', TO_DATE('2025-01-20', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (37, 3, 'Moteur Implantologie NSK', TO_DATE('2022-03-30', 'YYYY-MM-DD'), 'Fonctionnel', TO_DATE('2024-09-01', 'YYYY-MM-DD'));
INSERT INTO Equipements (id_equipement, id_franchise, nom_equipement, date_achat, etat, date_derniere_maintenance) 
VALUES (38, 5, 'Radio Portable Nomad Pro', TO_DATE('2023-11-11', 'YYYY-MM-DD'), 'Fonctionnel', TO_DATE('2024-11-11', 'YYYY-MM-DD'));

COMMIT;