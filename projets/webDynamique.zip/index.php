<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tchoutchou SNCF</title>
  <link rel="stylesheet" href="./styles/style.css">
</head>
<body>
  <section class="hero">
    <div class="hero-content">
      <h1><span class="highlight">Tchoutchou</span> SNCF</h1>
      <p class="lead">Analyse immersive des retards de trains</p>
      <a href="#contexte" class="btn-primary">Découvrir</a>
    </div>
    <div class="overlay"></div>
  </section>

  <section class="content" id="contexte">
    <div class="card">
      <h2>Contexte du projet</h2>
      <p>Ce projet consiste à développer une application web pour la SNCF, afin d'améliorer la gestion et la consultation des retards de trains.</p>
      <p>L'objectif principal est de fournir aux utilisateurs une interface conviviale pour accéder aux informations sur les horaires, les retards et les statistiques des trains en France.</p>
      <p>Nous analysons les retards des trains sur le réseau national français, à partir d'une base MySQL de ponctualité.</p>
      <p>Les données volumineuses incluent des informations détaillées sur les horaires des trains, les retards enregistrés et leurs causes.</p>
      <p>Pour faciliter l'analyse, le fichier CSV d'entrée a été découpé en <strong>4 tables</strong>, chacune contenant des données spécifiques telles que les horaires, les retards, les gares, etc.</p>
    </div>
  </section>

  <section class="content">
    <div class="card">
      <h2>Données analysées</h2>
      <?php
        // Inclusion du fichier de connexion à la base de données
        include ("./pages/connexion.php");

        function getDateRange($pdo, $table, $column = 'date_depart') {
            // Requête pour obtenir la première et dernière date
            $stmt = $pdo->query("SELECT MIN($column) AS debut, MAX($column) AS fin FROM $table");
            $row = $stmt->fetch();
            
            // Si des données sont trouvées, formater les dates
            if ($row && $row['debut'] && $row['fin']) {
                $debut = date("d/m/Y", strtotime($row['debut']));
                $fin = date("d/m/Y", strtotime($row['fin']));
                return "du $debut au $fin";
            }
        }

        function countTable($pdo, $table) {
            // Requête pour compter les enregistrements
            $stmt = $pdo->query("SELECT COUNT(*) AS total FROM $table");
            $row = $stmt->fetch();
            return $row['total'];
        }

        // Affichage du résumé des données présentes dans chaque table
        echo "<ul class='data-list'>";
            // Affiche le nombre total de gares
            echo "<li><strong>📍 Gares</strong> : " . countTable($pdo, 'gare') . " gares</li>";
            // Affiche le nombre de dates et la période couverte
            echo "<li><strong>📅 Dates</strong> : " . countTable($pdo, 'date_voyage') . " dates " . getDateRange($pdo, 'date_voyage') . "</li>";
            // Affiche le nombre total de statistiques
            echo "<li><strong>📊 Statistiques</strong> : " . countTable($pdo, 'stats') . " entrées</li>";
            // Affiche le nombre total de voyages
            echo "<li><strong>🚆 Voyages</strong> : " . countTable($pdo, 'voyage') . " voyages</li>";
        echo "</ul>";
    
    ?>
    </div>
  </section>

  <section class="content">
    <div class="card">
      <h2>Rejoignez la plateforme</h2>
      <p>Connectez-vous pour explorer les données en détail et visualiser les retards en temps réel.</p>
      <br>
      <a href="./pages/login.php" class="btn-primary">Connexion</a>
    </div>
  </section>

  <footer class="footer">
    © 2025 Tchoutchou SNCF — Tous droits réservés.
  </footer>
</body>
</html>
