<?php
/**
 * Fichier : modifier_donnees.php
 * Description : Interface de modification des données de la base
 * 
 * Ce fichier permet aux administrateurs et gestionnaires de :
 * - Modifier les informations des gares
 * - Gérer les dates de voyage
 * - Mettre à jour les statistiques
 * - Supprimer des entrées (avec vérification des contraintes)
 */

// Démarrage de la session
session_start();

// Inclusion du fichier de connexion à la base de données
require 'connexion.php';

// Vérification des droits d'accès (admin ou gestionnaire uniquement)
if (!isset($_SESSION['user']) || !in_array($_SESSION['user']['droits'], ['admin', 'gestionnaire'])) {
    header('Location: login.php');
    exit;
}

// Détermination du rôle et de la page de retour
$role = $_SESSION['user']['droits'];
$retour_page = ($role === 'admin') ? 'admin.php' : 'gestionnaire.php';

/**
 * Traitement des formulaires soumis en POST
 * - Validation des données
 * - Exécution des requêtes SQL
 * - Gestion des messages de retour
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Traitement des modifications de gares
        if (isset($_POST['update_gare'])) {
            // Récupération et nettoyage des données
            $gare_id = (int)$_POST['gare_id'];
            $nom = trim($_POST['nom']);

            // Validation des données
            if ($gare_id > 0 && $nom !== '') {
                // Mise à jour de la gare dans la base
                $stmt = $pdo->prepare("UPDATE gare SET nom = ? WHERE gare_id = ?");
                $stmt->execute([$nom, $gare_id]);
                
                // Message de succès
                $_SESSION['flash'] = [
                    'type' => 'success',
                    'msg' => "✅ Gare mise à jour avec succès."
                ];
            } else {
                // Message d'erreur si données invalides
                $_SESSION['flash'] = [
                    'type' => 'error',
                    'msg' => "⚠️ Données gare invalides."
                ];
            }
        }
        // Traitement des suppressions de gares
        if (isset($_POST['delete_gare'])) {
            // Récupération et validation de l'ID
            $gare_id = (int)$_POST['gare_id'];
            if ($gare_id > 0) {
                try {
                    // Tentative de suppression de la gare
                    $stmt = $pdo->prepare("DELETE FROM gare WHERE gare_id = ?");
                    $stmt->execute([$gare_id]);
                    
                    // Message de succès
                    $_SESSION['flash'] = [
                        'type' => 'success',
                        'msg' => "🗑️ Gare supprimée avec succès."
                    ];
                } catch (PDOException $e) {
                    // Gestion des erreurs de suppression
                    if ($e->getCode() === '23000') {
                        // Erreur de contrainte référentielle
                        $_SESSION['flash'] = [
                            'type' => 'error',
                            'msg' => "❌ Impossible de supprimer cette gare : elle est utilisée dans un voyage ou des statistiques."
                        ];
                    } else {
                        // Autre erreur SQL
                        $_SESSION['flash'] = [
                            'type' => 'error',
                            'msg' => "Erreur lors de la suppression : " . htmlspecialchars($e->getMessage())
                        ];
                    }
                }
            }
        }

        /**
         * Gestion des dates de voyage
         * - Mise à jour des dates existantes
         * - Validation du format des dates
         */
        if (isset($_POST['update_date'])) {
            // Récupération et nettoyage des données
            $date_id = (int)$_POST['date_id'];
            $date_depart = trim($_POST['date_depart']);
            
            // Validation des données
            if ($date_id > 0 && $date_depart !== '') {
                // Mise à jour de la date dans la base
                $stmt = $pdo->prepare("UPDATE date_voyage SET date_depart = ? WHERE date_id = ?");
                $stmt->execute([$date_depart, $date_id]);
                
                // Message de succès
                $_SESSION['flash'] = [
                    'type' => 'success',
                    'msg' => "✅ Date mise à jour."
                ];
            } else {
                // Message d'erreur si données invalides
                $_SESSION['flash'] = [
                    'type' => 'error',
                    'msg' => "⚠️ Données date invalides."
                ];
            }
        }
        /**
         * Suppression d'une date de voyage
         * - Vérification des contraintes référentielles
         * - Gestion des erreurs de suppression
         */
        if (isset($_POST['delete_date'])) {
            // Récupération et validation de l'ID
            $date_id = (int)$_POST['date_id'];
            
            if ($date_id > 0) {
                try {
                    // Tentative de suppression de la date
                    $stmt = $pdo->prepare("DELETE FROM date_voyage WHERE date_id = ?");
                    $stmt->execute([$date_id]);
                    
                    // Message de succès
                    $_SESSION['flash'] = [
                        'type' => 'success',
                        'msg' => "🗑️ Date supprimée."
                    ];
                } catch (PDOException $e) {
                    // Gestion des erreurs de suppression
                    if ($e->getCode() === '23000') {
                        // Erreur de contrainte référentielle
                        $_SESSION['flash'] = [
                            'type' => 'error',
                            'msg' => "❌ Impossible de supprimer cette date : elle est utilisée dans une ligne."
                        ];
                    } else {
                        // Autre erreur SQL
                        $_SESSION['flash'] = [
                            'type' => 'error',
                            'msg' => "Erreur lors de la suppression : " . htmlspecialchars($e->getMessage())
                        ];
                    }
                }
            }
        }

        /**
         * Mise à jour des statistiques de voyage
         * - Gestion des durées moyennes
         * - Gestion des retards et leurs causes
         * - Calcul des pourcentages
         */
        if (isset($_POST['update_stats'])) {
            // Récupération et nettoyage des données statistiques
            $stats_id = (int)$_POST['stats_id'];
            
            // Données temporelles
            $duree_moyenne = trim($_POST['duree_moyenne']);
            $nb_circulations = trim($_POST['nb_circulations']);
            
            // Statistiques de retard au départ
            $nb_retard_depart = trim($_POST['nb_retard_depart']);
            $retard_moyen_depart_retard = trim($_POST['retard_moyen_depart_retard']);
            
            // Statistiques de retard à l'arrivée
            $nb_retard_arrivee = trim($_POST['nb_retard_arrivee']);
            $retard_moyen_arrivee_retard = trim($_POST['retard_moyen_arrivee_retard']);
            $retard_moyen_arrivee_total = trim($_POST['retard_moyen_arrivee_total']);
            
            // Retards significatifs
            $nb_retard_15 = trim($_POST['nb_retard_15']);
            $retard_moyen_15 = trim($_POST['retard_moyen_15']);
            $nb_retard_60 = trim($_POST['nb_retard_60']);
            
            // Pourcentages par cause de retard
            $prct_retard_externe = trim($_POST['prct_retard_externe']);
            $prct_retard_infra = trim($_POST['prct_retard_infra']);
            $prct_retard_materiel = trim($_POST['prct_retard_materiel']);
            $prct_retard_gare = trim($_POST['prct_retard_gare']);
            $prct_retard_voyageurs = trim($_POST['prct_retard_voyageurs']);
            
            // Préparation de la requête de mise à jour
            $stmt = $pdo->prepare("
                UPDATE stats 
                SET 
                    duree_moyenne = ?,
                    nb_circulations = ?,
                    nb_retard_depart = ?,
                    retard_moyen_depart_retard = ?,
                    nb_retard_arrivee = ?,
                    retard_moyen_arrivee_retard = ?,
                    retard_moyen_arrivee_total = ?,
                    nb_retard_15 = ?,
                    retard_moyen_15 = ?,
                    nb_retard_60 = ?,
                    prct_retard_externe = ?,
                    prct_retard_infra = ?,
                    prct_retard_materiel = ?,
                    prct_retard_gare = ?,
                    prct_retard_voyageurs = ?
                WHERE stats_id = ?
            ");

            // Exécution de la requête avec les paramètres
            $stmt->execute([
                $duree_moyenne,
                $nb_circulations,
                $nb_retard_depart,
                $retard_moyen_depart_retard,
                $nb_retard_arrivee,
                $retard_moyen_arrivee_retard,
                $retard_moyen_arrivee_total,
                $nb_retard_15,
                $retard_moyen_15,
                $nb_retard_60,
                $prct_retard_externe,
                $prct_retard_infra,
                $prct_retard_materiel,
                $prct_retard_gare,
                $prct_retard_voyageurs,
                $stats_id
            ]);

            // Message de confirmation
            $_SESSION['flash'] = [
                'type' => 'success',
                'msg' => "✅ Statistique #$stats_id mise à jour."
            ];
        }
        /**
         * Suppression d'une statistique
         * - Vérification des contraintes référentielles
         * - Protection contre la suppression de données liées
         */
        if (isset($_POST['delete_stats'])) {
            // Récupération de l'ID de la statistique
            $stats_id = (int)$_POST['stats_id'];
            
            try {
                // Tentative de suppression de la statistique
                $stmt = $pdo->prepare("DELETE FROM stats WHERE stats_id = ?");
                $stmt->execute([$stats_id]);
                
                // Message de succès
                $_SESSION['flash'] = [
                    'type' => 'success',
                    'msg' => "🗑️ Statistique supprimée."
                ];
            } catch (PDOException $e) {
                // Message d'erreur en cas de contrainte référentielle
                $_SESSION['flash'] = [
                    'type' => 'error',
                    'msg' => "❌ Impossible de supprimer cette statistique : utilisée dans un voyage."
                ];
            }
        }

        /**
         * Gestion des voyages
         * - Mise à jour des informations de voyage
         * - Relations avec les gares, dates et statistiques
         */
        if (isset($_POST['update_voyage'])) {
            // Récupération et nettoyage des données du voyage
            $voyage_id = (int)$_POST['voyage_id'];
            $stats_id = trim($_POST['stats_id']);
            $gare_depart_id = trim($_POST['gare_depart_id']);
            $gare_arrivee_id = trim($_POST['gare_arrivee_id']);
            $date_id = trim($_POST['date_id']);

            // Préparation et exécution de la requête de mise à jour
            $stmt = $pdo->prepare("
                UPDATE voyage 
                SET 
                    stats_id = ?,
                    gare_depart_id = ?,
                    gare_arrivee_id = ?,
                    date_id = ?
                WHERE voyage_id = ?
            ");
            
            // Exécution avec les paramètres
            $stmt->execute([
                $stats_id,
                $gare_depart_id,
                $gare_arrivee_id,
                $date_id,
                $voyage_id
            ]);

            // Message de confirmation
            $_SESSION['flash'] = [
                'type' => 'success',
                'msg' => "✅ Voyage #$voyage_id mis à jour."
            ];
        }
        /**
         * Suppression d'un voyage
         * - Vérification des contraintes référentielles
         * - Protection contre la suppression de données liées
         */
        if (isset($_POST['delete_voyage'])) {
            // Récupération de l'ID du voyage
            $voyage_id = (int)$_POST['voyage_id'];
            
            try {
                // Tentative de suppression du voyage
                $stmt = $pdo->prepare("DELETE FROM voyage WHERE voyage_id = ?");
                $stmt->execute([$voyage_id]);
                
                // Message de succès
                $_SESSION['flash'] = [
                    'type' => 'success',
                    'msg' => "🗑️ Voyage supprimé."
                ];
            } catch (PDOException $e) {
                // Message d'erreur en cas de contrainte référentielle
                $_SESSION['flash'] = [
                    'type' => 'error',
                    'msg' => "❌ Impossible de supprimer ce voyage : il est lié à d'autres données."
                ];
            }
        }

    } catch (Exception $e) {
        $_SESSION['flash'] = ['type'=>'error','msg'=>"❌ Erreur inattendue : " . htmlspecialchars($e->getMessage())];
    }

    header("Location: " . strtok($_SERVER['REQUEST_URI'], '?'));
    exit;
}

/**
 * Fonction de recherche générique
 * - Permet de rechercher dans une table et une colonne spécifiques
 * - Limite le nombre de résultats pour éviter les surcharges
 */
function search($pdo, $table, $column, $value) {
    // Préparation de la requête avec une limite de résultats
    $stmt = $pdo->prepare("
        SELECT * 
        FROM $table 
        WHERE $column LIKE ? 
        LIMIT 100
    ");
    
    // Exécution avec le motif de recherche
    $stmt->execute(["%$value%"]);
    
    // Retour des résultats
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Récupération des termes de recherche depuis l'URL
$search_gare = isset($_GET['search_gare']) ? $_GET['search_gare'] : '';
$search_date = isset($_GET['search_date']) ? $_GET['search_date'] : '';
$search_stats = isset($_GET['search_stats']) ? $_GET['search_stats'] : '';
$search_voyage = isset($_GET['search_voyage']) ? $_GET['search_voyage'] : '';

// Recherche des gares par nom
$gares = $search_gare ? search($pdo, 'gare', 'nom', $search_gare) : [];

// Recherche des dates de voyage
$dates = $search_date ? search($pdo, 'date_voyage', 'date_depart', $search_date) : [];

// Initialisation des variables pour les résultats
$stat_result = null;
$voyage_result = null;

// Recherche d'une statistique spécifique par ID
if ($search_stats !== '') {
    $stmt = $pdo->prepare("SELECT * FROM stats WHERE stats_id = ?");
    $stmt->execute([$search_stats]);
    $stat_result = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Recherche d'un voyage spécifique par ID
if ($search_voyage !== '') {
    $stmt = $pdo->prepare("SELECT * FROM voyage WHERE voyage_id = ?");
    $stmt->execute([$search_voyage]);
    $voyage_result = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SNCF - Modification Données</title>
    <link rel="stylesheet" href="./../styles/style.css">
    <style>
        td {
            border-bottom: 0px solid #ccc;
        }
    </style>
</head>
<body>
  <section class="hero">
    <div class="hero-content">
      <h1><span class="highlight">Tchoutchou</span> SNCF</h1>
      <p class="lead"><strong>Gestion des données</strong><br>Ajouter, modifier ou supprimer des enregistrements</p>
      <a href="#contenu" class="btn-primary">Découvrir</a>
    </div>
    <div class="overlay"></div>
  </section>

    <section class="content" id="contenu">
        <div class="card">
            <div style="text-align: center; margin-top: 20px;">
                <a href="./ajout_donnees.php">Ajouter des données</a>
            </div>
            <?php if (!empty($_SESSION['flash'])): $f=$_SESSION['flash'];unset($_SESSION['flash']);
            echo "<div class=\"alert " . ($f['type']==='success'?'alert-success':'alert-error') . "\">";
                echo $f['msg'];
            echo "</div>";
            endif; ?>
            
            <!-- === GARES === -->
            <table>
            <tr><td><h2>🚉 Gares</h2></td></tr>
            <tr>
            <form method="get" class="actions">
                <td><input type="text" name="search_gare" placeholder="Rechercher une gare" value="<?= $search_gare ?>"></td>
                <td><button type="submit" class="btn">Rechercher</button></td>
            </form>
            </tr>
            <?php foreach ($gares as $gare):
                echo "<tr>";
                echo "<form method=\"post\" class=\"actions\">";
                    echo "<input type=\"hidden\" name=\"gare_id\" value=\"{$gare['gare_id']}\">";
                    echo "<td><input type=\"text\" name=\"nom\" value=\"" . $gare['nom'] . "\"></td>";
                    echo "<td><button type=\"submit\" name=\"update_gare\" class=\"btn\">Modifier</button>";
                    echo "<button type=\"submit\" name=\"delete_gare\" class=\"btn-supp\" onclick=\"return confirm('Supprimer cette gare ?')\">Supprimer</button></td>";
                echo "</form>";
                echo "</tr>";
            endforeach; ?>

            <!-- === DATES === -->
            <tr><td><h2>📅 Dates de voyage</h2></td></tr>
            <tr>
            <form method="get" class="actions">
                <td><input type="text" name="search_date" placeholder="Rechercher une date (AAAA-MM-JJ)" value="<?= $search_date ?>"></td>
                <td><button type="submit" class="btn">Rechercher</button></td>
            </form>
            </tr>
            <?php foreach ($dates as $date):
                echo "<tr>";
                echo "<form method=\"post\" class=\"actions\">";
                    echo "<input type=\"hidden\" name=\"date_id\" value=\"{$date['date_id']}\">";
                    echo "<td><input type=\"text\" name=\"date_depart\" value=\"" . $date['date_depart'] . "\"></td>";
                    echo "<td><button type=\"submit\" name=\"update_date\" class=\"btn\">Modifier</button>";
                    echo "<button type=\"submit\" name=\"delete_date\" class=\"btn-supp\" onclick=\"return confirm('Supprimer cette date ?')\">Supprimer</button></td>";
                echo "</form>";
                echo "</tr>";
            endforeach; ?>

            <!-- === STATS === -->
            <tr><td><h2>📊 Statistiques</h2></td></tr>
            <tr>
            <form method="get" class="actions">
                <td><input type="number" min="1" name="search_stats" placeholder="Entrer ID statistique" value="<?= $search_stats ?>"></td>
                <td><button type="submit" class="btn">Rechercher</button></td>
            </form>
            </tr>
            <?php if ($stat_result):
            echo "<form method=\"post\" class=\"actions\">";
                echo "<input type=\"hidden\" name=\"stats_id\" value=\"{$stat_result['stats_id']}\">";
                echo "<tr>";
                    echo "<td><label>duree_moyenne</label><input type=\"number\" min=\"0\" name=\"duree_moyenne\" value=\"" . $stat_result['duree_moyenne'] . "\"></td>";
                    echo "<td><label>nb_circulations</label><input type=\"number\" min=\"0\" name=\"nb_circulations\" value=\"" . $stat_result['nb_circulations'] . "\"></td>";
                echo "</tr>";
                // Champs pour les retards au départ
                echo "<tr>";
                    echo "<td><label>nb_retard_depart</label><input type=\"number\" min=\"0\" name=\"nb_retard_depart\" value=\"" . $stat_result['nb_retard_depart'] . "\" title=\"Nombre de retards au départ\"></td>";
                    echo "<td><label>retard_moyen_depart_retard</label><input type=\"number\" min=\"0\" step=\"0.01\" name=\"retard_moyen_depart_retard\" value=\"" . $stat_result['retard_moyen_depart_retard'] . "\" title=\"Retard moyen au départ (en minutes)\"></td>";
                echo "</tr>";

                // Champs pour les retards à l'arrivée
                echo "<tr>";
                    echo "<td><label>nb_retard_arrivee</label><input type=\"number\" min=\"0\" name=\"nb_retard_arrivee\" value=\"" . $stat_result['nb_retard_arrivee'] . "\" title=\"Nombre de retards à l'arrivée\"></td>";
                    echo "<td><label>retard_moyen_arrivee_retard</label><input type=\"number\" min=\"0\" step=\"0.01\" name=\"retard_moyen_arrivee_retard\" value=\"" . $stat_result['retard_moyen_arrivee_retard'] . "\" title=\"Retard moyen à l'arrivée pour les trains en retard (en minutes)\"></td>";
                echo "</tr>";

                // Statistiques globales des retards
                echo "<tr>";
                    echo "<td><label>retard_moyen_arrivee_total</label><input type=\"number\" min=\"0\" step=\"0.01\" name=\"retard_moyen_arrivee_total\" value=\"" . $stat_result['retard_moyen_arrivee_total'] . "\" title=\"Retard moyen à l'arrivée tous trains confondus\"></td>";
                    echo "<td><label>nb_retard_15</label><input type=\"number\" min=\"0\" name=\"nb_retard_15\" value=\"" . $stat_result['nb_retard_15'] . "\" title=\"Nombre de retards supérieurs à 15 minutes\"></td>";
                echo "</tr>";

                // Retards par durée
                echo "<tr>";
                    echo "<td><label>retard_moyen_15</label><input type=\"number\" min=\"0\" step=\"0.01\" name=\"retard_moyen_15\" value=\"" . $stat_result['retard_moyen_15'] . "\" title=\"Retard moyen pour les retards > 15 min\"></td>";
                    echo "<td><label>nb_retard_60</label><input type=\"number\" min=\"0\" name=\"nb_retard_60\" value=\"" . $stat_result['nb_retard_60'] . "\" title=\"Nombre de retards supérieurs à 60 minutes\"></td>";
                echo "</tr>";

                // Pourcentages des causes de retard (externes et infrastructure)
                echo "<tr>";
                    echo "<td><label>prct_retard_externe</label><input type=\"number\" min=\"0\" step=\"0.01\" name=\"prct_retard_externe\" value=\"" . $stat_result['prct_retard_externe'] . "\" title=\"Pourcentage des retards dus à des causes externes\"></td>";
                    echo "<td><label>prct_retard_infra</label><input type=\"number\" min=\"0\" step=\"0.01\" name=\"prct_retard_infra\" value=\"" . $stat_result['prct_retard_infra'] . "\" title=\"Pourcentage des retards dus à l'infrastructure\"></td>";
                echo "</tr>";

                // Pourcentages des causes de retard (matériel et gare)
                echo "<tr>";
                    echo "<td><label>prct_retard_materiel</label><input type=\"number\" min=\"0\" step=\"0.01\" name=\"prct_retard_materiel\" value=\"" . $stat_result['prct_retard_materiel'] . "\" title=\"Pourcentage des retards dus au matériel roulant\"></td>";
                    echo "<td><label>prct_retard_gare</label><input type=\"number\" min=\"0\" step=\"0.01\" name=\"prct_retard_gare\" value=\"" . $stat_result['prct_retard_gare'] . "\" title=\"Pourcentage des retards dus aux gares\"></td>";
                echo "</tr>";

                // Pourcentage des retards liés aux voyageurs
                echo "<tr>";
                    echo "<td><label>prct_retard_voyageurs</label><input type=\"number\" min=\"0\" step=\"0.01\" name=\"prct_retard_voyageurs\" value=\"" . $stat_result['prct_retard_voyageurs'] . "\" title=\"Pourcentage des retards dus aux voyageurs\"></td>";
                echo "</tr>";

                // Boutons d'action
                echo "<tr>";
                    echo "<td></td>";
                    echo "<td>";
                        echo "<button type=\"submit\" name=\"update_stats\" class=\"btn\">Modifier</button>";
                        echo "<button type=\"submit\" name=\"delete_stats\" class=\"btn-supp\" onclick=\"return confirm('Supprimer cette statistique ?')\">Supprimer</button>";
                    echo "</td>";
                echo "</tr>";
            echo "</form>";
            elseif ($search_stats!==''):
                // Message d'erreur si aucune statistique n'est trouvée
                echo "<p class=\"small\">❌ Aucune statistique trouvée avec cet ID.</p>";
            endif; ?>

            <!-- === Section de gestion des voyages === -->
            <tr><td><h2>🚆 Voyages</h2></td></tr>
            
            <!-- Formulaire de recherche de voyage -->
            <tr>
            <form method="get" class="actions">
                <td><input type="number" min="1" name="search_voyage" placeholder="Entrer ID voyage" value="<?= $search_voyage ?>" title="Entrez l'identifiant du voyage à rechercher"></td>
                <td><button type="submit" class="btn">Rechercher</button></td>
            </form>
            </tr>
            
            <!-- Affichage et modification des détails du voyage -->
            <?php if ($voyage_result):
            echo "<form method=\"post\" class=\"actions\">";
                // ID du voyage caché pour le traitement du formulaire
                echo "<input type=\"hidden\" name=\"voyage_id\" value=\"". $voyage_result['voyage_id'] ."\"></input>";

                //Champs pour les IDs de statistiques et gares de départ
                echo "<tr>";
                echo "<td><label>stats_id</label><input type=\"number\" min=\"1\" name=\"stats_id\" value=\"". $voyage_result['stats_id'] ."\" title=\"ID des statistiques associées\"></td>";
                echo "<td><label>gare_depart_id</label><input type=\"number\" min=\"1\" name=\"gare_depart_id\" value=\"". $voyage_result['gare_depart_id'] ."\" title=\"ID de la gare de départ\"></td>";
                echo "</tr>";

                // Champs pour la gare d'arrivée et la date
                echo "<tr>";
                echo "<td><label>gare_arrivee_id</label><input type=\"number\" min=\"1\" name=\"gare_arrivee_id\" value=\"". $voyage_result['gare_arrivee_id'] ."\" title=\"ID de la gare d'arrivée\"></td>";
                echo "<td><label>date_id</label><input type=\"number\" min=\"1\" name=\"date_id\" value=\"". $voyage_result['date_id'] ."\" title=\"ID de la date du voyage\"></td>";
                echo "</tr>";
                
                // Boutons d'action pour le voyage
                echo "<tr>";
                echo "<td></td>";
                echo "<td>";
                    echo "<button type=\"submit\" name=\"update_voyage\" class=\"btn\" title=\"Enregistrer les modifications\">Modifier</button>";
                    echo "<button type=\"submit\" name=\"delete_voyage\" class=\"btn-supp\" onclick=\"return confirm('Supprimer ce voyage ?')\" title=\"Supprimer définitivement ce voyage\">Supprimer</button>";
                echo "</td>";
                echo "</tr>";
            echo "</form>";
            elseif ($search_voyage!==''):
            // Message d'erreur si aucun voyage n'est trouvé
            echo "<p class=\"small\">❌ Aucun voyage trouvé avec cet ID.</p>";
            endif; ?>
            
            </table>
            
            <!-- Lien de retour vers la page d'accueil -->
            <p class="small">
                <a href="<?= $retour_page ?>" title="Retourner à la page d'accueil">← Retour à l'accueil <?= $role ?></a>
            </p>
        </div>
    </section>
    <footer class="footer">
        © 2025 Tchoutchou SNCF — Tous droits réservés.
    </footer>
    </body>
</html>
