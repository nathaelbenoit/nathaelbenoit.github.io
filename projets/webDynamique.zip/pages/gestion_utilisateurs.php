<?php
/**
 * Fichier : gestion_utilisateurs.php
 * Description : Interface d'administration des utilisateurs
 * 
 * Ce fichier permet à l'administrateur de :
 * - Visualiser la liste des utilisateurs
 * - Modifier les droits des utilisateurs
 * - Supprimer des comptes utilisateurs
 * 
 * Sécurité :
 * - Accès restreint aux administrateurs
 * - Protection contre la suppression de son propre compte
 * - Requêtes préparées pour prévenir les injections SQL
 */

// Démarrage de la session
session_start();

// Inclusion du fichier de connexion à la base de données
require 'connexion.php';

// Vérification des droits d'accès
if (!isset($_SESSION['user']) || $_SESSION['user']['droits'] !== 'admin') {
    header('Location: login.php');
    exit;
}

// --- Suppression d’un utilisateur ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_user_id'])) {
    $delete_user_id = $_POST['delete_user_id'];

    // Empêche la suppression de soi-même
    if ($delete_user_id != $_SESSION['user']['id']) {
        $stmt = $pdo->prepare("DELETE FROM co WHERE id = ?");
        $stmt->execute([$delete_user_id]);
    }
}

// --- Mise à jour des droits ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_id'], $_POST['new_droits'])) {
    $user_id = $_POST['user_id'];
    $new_droits = $_POST['new_droits'];

    $stmt = $pdo->prepare("UPDATE co SET droits = ? WHERE id = ?");
    $stmt->execute([$new_droits, $user_id]);
}

// --- Récupération des utilisateurs ---
$stmt = $pdo->query("SELECT id, username, droits FROM co ORDER BY username");
$users = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SNCF - Gestion Utilisateur</title>
    <link rel="stylesheet" href="./../styles/style.css">
</head>
<body>
    <section class="hero">
        <div class="hero-content">
            <h1><span class="highlight">Tchoutchou</span> SNCF</h1>
            <p class="lead"><strong>Gestion des utilisateurs</strong><br>Modifier les rôles ou supprimer des utilisateurs</p>
            <a href="#contenu" class="btn-primary">Découvrir</a>
        </div>
        <div class="overlay"></div>
    </section>

  <section class="content" id="contenu">
    <div class="card">
            <!-- Tableau de gestion des utilisateurs -->
            <table>
                <thead>
                    <tr>
                        <th>Nom d'utilisateur</th>
                        <th>Rôle actuel</th>
                        <th>Changer le rôle</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): 
                        echo "<tr>";
                            // Affichage du nom d'utilisateur sécurisé contre XSS
                            echo "<td>". $user['username'] ."</td>";
                            // Affichage du rôle actuel
                            echo "<td>". $user['droits'] ."</td>";
                            echo "<td>";
                                // Formulaire de modification des droits
                                echo "<form method=\"post\" class=\"actions\">";
                                    echo "<input type=\"hidden\" name=\"user_id\" value=\"". $user['id'] ."\">";
                                    echo "<select name=\"new_droits\" style=\"padding:6px; border-radius:6px;\">";
                                        echo "<option value=\"voyageur\" ". ($user['droits'] === 'voyageur' ? 'selected' : '') ."> Voyageur </option>";
                                        echo "<option value=\"gestionnaire\" ". ($user['droits'] === 'gestionnaire' ? 'selected' : '') ."> Gestionnaire </option>";
                                        echo "<option value=\"admin\" ". ($user['droits'] === 'admin' ? 'selected' : '') ."> Admin </option>";
                                    echo "</select>";
                            echo "</td>";
                            echo "<td>";
                                    echo "<button type=\"submit\" class=\"btn\">Modifier</button>";
                                echo "</form>";

                                if ($user['id'] != $_SESSION['user']['id']):
                                    // Formulaire de suppression d'utilisateur avec confirmation
                                    echo "<form method=\"post\" onsubmit=\"return confirm('Voulez-vous vraiment supprimer cet utilisateur ?');\">";
                                        echo "<input type=\"hidden\" name=\"delete_user_id\" value=\"".$user['id']."\">";
                                        echo "<button type=\"submit\" class=\"btn-supp\">Supprimer</button>";
                                    echo "</form>";
                                else:
                                    // Indication pour l'utilisateur courant
                                    echo "<p>Vous-même</p>";
                                endif;
                            echo "</td>";
                        echo "</tr>";
                    endforeach; ?>
                </tbody>
            </table>

            <!-- Lien de navigation -->
            <p class="small"><a href="./admin.php" title="Retourner au panneau d'administration">← Retour à l'accueil admin</a></p>
        </div>
    </section>
    <footer class="footer">
        © 2025 Tchoutchou SNCF — Tous droits réservés.
    </footer>
</body>
</html>
