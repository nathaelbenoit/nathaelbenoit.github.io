<?php
session_start();
/**
 * Fichier : maj_db.php
 * Description : Mise à jour de la base de données via import CSV
 * 
 * Configuration requise dans php.ini :
 * - upload_max_filesize = 3M (au lieu de 2M)
 * - post_max_size = 8M
 * - max_execution_time = 120 (au lieu de 30)
 * - memory_limit = 256M (au lieu de 126M)
 * Chemin du php.ini : C:\...\EasyPHP-Devserver-17\eds-binaries\php\php8.0\php.ini
 */

// Paramètres de connexion à la base de données
$host = "localhost";    // Serveur de base de données
$dbname = "tchoutchou"; // Nom de la base de données
$user = "root";         // Nom d'utilisateur MySQL
$pass = "";            // Mot de passe MySQL

// Établissement de la connexion à la base de données
$conn = new mysqli($host, $user, $pass, $dbname);

// Vérification de la connexion
if ($conn->connect_error) {
    die("Erreur de connexion : " . $conn->connect_error);
}

function cleanGareName($name) {
    return strtoupper(trim($name));
}

function cleanDate($date) {
    return trim($date) . "-01";
}

// Traitement du formulaire d'import CSV
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_FILES["csv_file"])) {
    // Récupération du fichier téléchargé
    $fileName = $_FILES["csv_file"]["tmp_name"];
    
    // Vérification du succès du téléchargement
    if ($_FILES["csv_file"]["error"] === 0 && is_uploaded_file($fileName)) {
        // Ouverture du fichier CSV
        if (($handle = fopen($fileName, "r")) !== FALSE) {
            // Ignorer la première ligne (en-têtes)
            fgetcsv($handle, 1000, ";");

            // Vérification du format du fichier (nombre de colonnes)
            $firstLine = fgetcsv($handle, 1000, ";");
            if (count($firstLine) >= 26) {
                // Retour au début du fichier (après les en-têtes)
                rewind($handle);
                fgetcsv($handle, 1000, ";");

                // Liste des tables à vider avant l'import
                $tables = ["voyage", "stats", "date_voyage", "gare"];
                
                // Désactivation temporaire des vérifications de clés étrangères
                $conn->query("SET FOREIGN_KEY_CHECKS = 0");
                
                // Vidage de toutes les tables concernées
                foreach ($tables as $table) {
                    $conn->query("TRUNCATE TABLE `$table`");
                }
                
                // Réactivation des vérifications de clés étrangères
                $conn->query("SET FOREIGN_KEY_CHECKS = 1");

                $conn->begin_transaction();
                $counter = 0;

                while (($data = fgetcsv($handle, 1000, ";")) !== FALSE) {
                    if (count($data) < 26) continue;

                    $dateSQL = cleanDate($data[0]);
                    $gareDepart = cleanGareName($conn->real_escape_string($data[2]));
                    $gareArrivee = cleanGareName($conn->real_escape_string($data[3]));

                    $dureeMoyenne = (int)$data[4];
                    $nbCirculations = (int)$data[5];
                    $nbRetardDepart = (int)$data[8];
                    $retardMoyenDepart = (float)$data[9];
                    $nbRetardArrivee = (int)$data[12];
                    $retardMoyenArrivee = (float)$data[13];
                    $nbRetard15 = (int)$data[16];
                    $retardMoyen15 = (float)$data[17];
                    $nbRetard60 = (int)$data[19];
                    $prctExterne = (float)$data[20];
                    $prctInfra = (float)$data[21];
                    $prctMateriel = (float)$data[23];
                    $prctGare = (float)$data[24];
                    $prctVoyageurs = (float)$data[25];

                    // Insert gares
                    $conn->query("INSERT IGNORE INTO gare (nom) VALUES ('$gareDepart')");
                    $conn->query("INSERT IGNORE INTO gare (nom) VALUES ('$gareArrivee')");
                    $gareDepartId = $conn->query("SELECT gare_id FROM gare WHERE nom='$gareDepart'")->fetch_assoc()['gare_id'];
                    $gareArriveeId = $conn->query("SELECT gare_id FROM gare WHERE nom='$gareArrivee'")->fetch_assoc()['gare_id'];

                    // Insert date
                    $conn->query("INSERT IGNORE INTO date_voyage (date_depart) VALUES ('$dateSQL')");
                    $dateId = $conn->query("SELECT date_id FROM date_voyage WHERE date_depart='$dateSQL'")->fetch_assoc()['date_id'];

                    // Insert stats
                    $conn->query("INSERT INTO stats (
                        duree_moyenne, nb_circulations, nb_retard_depart, retard_moyen_depart_retard,
                        nb_retard_arrivee, retard_moyen_arrivee_retard, retard_moyen_arrivee_total,
                        nb_retard_15, retard_moyen_15, nb_retard_60,
                        prct_retard_externe, prct_retard_infra, prct_retard_materiel,
                        prct_retard_gare, prct_retard_voyageurs
                    ) VALUES (
                        $dureeMoyenne, $nbCirculations, $nbRetardDepart, $retardMoyenDepart,
                        $nbRetardArrivee, $retardMoyenArrivee, $retardMoyenArrivee,
                        $nbRetard15, $retardMoyen15, $nbRetard60,
                        $prctExterne, $prctInfra, $prctMateriel,
                        $prctGare, $prctVoyageurs
                    )");

                    $statsId = $conn->insert_id;

                    // Insert voyage
                    $conn->query("INSERT INTO voyage (stats_id, gare_depart_id, gare_arrivee_id, date_id)
                                VALUES ($statsId, $gareDepartId, $gareArriveeId, $dateId)");

                    $counter++;
                }

                $conn->commit();
                fclose($handle);
                $_SESSION['import_status'] = array(
                    'message' => "Importation terminée avec succès",
                    'type' => 'success'
                );
            }
            else {
                $_SESSION['import_status'] = array(
                    'message' => "Fichier CSV invalide.",
                    'type' => 'error'
                );
            }  
        }
    }
}

// Récupérer le message s'il existe
$status_message = '';
$status_type = '';
if (isset($_SESSION['import_status'])) { 
    $status_message = $_SESSION['import_status']['message'];
    $status_type = $_SESSION['import_status']['type'];
    unset($_SESSION['import_status']); // Effacer le message après l'avoir récupéré
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SNCF - MAJ BDD</title>
  <link rel="stylesheet" href="./../styles/style.css">
</head>
<body>
  <section class="hero">
    <div class="hero-content">
      <h1><span class="highlight">Tchoutchou</span> SNCF</h1>
      <p class="lead"><strong>Mise à jour de la base de donnée</strong><br>Insertion de données pour mettre à jour la base Tchoutchou</p>
      <a href="#contenu" class="btn-primary">Découvrir</a>
    </div>
    <div class="overlay"></div>
  </section>

    <section class="content" id="contenu">
        <div class="card">
            <h2>Importer un fichier CSV</h2>
            <form method="POST" enctype="multipart/form-data" class="upload-form">
                <div class="file-upload-zone">
                    <input type="file" name="csv_file" accept=".csv" required id="csv_upload">
                    <label for="csv_upload">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48" style="fill:none;stroke:currentColor;stroke-width:2">
                            <path d="M12 15V3m0 0L8 7m4-4l4 4M20 21H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 2h7a2 2 0 012 2v12a2 2 0 01-2 2z"/>
                        </svg>
                        <div class="upload-text">
                            <strong>Cliquez pour choisir un fichier CSV</strong>
                            <span>ou glissez-le ici</span>
                        </div>
                    </label>
                </div>
                <?php if (!empty($status_message)):
                    echo '<div class="import-status ' . $status_type . ' visible">';
                        echo $status_message;
                    echo '</div>';
                endif; ?>
                <button type="submit" class="btn-import">Lancer l'importation</button>
            </form>
            <p>Le téléchargement du fichier durera maximum 2 minutes.</p>
            <p class="small"><a href="./admin.php">← Retour à l’accueil admin</a></p>
        </div>
    </section>
    <footer class="footer">
        © 2025 Tchoutchou SNCF — Tous droits réservés.
    </footer>
</body>
</html>