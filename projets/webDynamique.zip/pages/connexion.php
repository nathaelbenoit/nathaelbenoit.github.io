<?php
/**
 * Fichier : connexion.php
 * Description : Gestion de la connexion à la base de données MySQL
 * 
 * Ce fichier établit la connexion à la base de données MySQL utilisée par l'application.
 * Il définit les paramètres de connexion et crée une instance PDO sécurisée.
 */

// Paramètres de connexion à la base de données
$host = 'localhost';    // Adresse du serveur MySQL
$db   = 'tchoutchou';  // Nom de la base de données
$user = 'root';        // Nom d'utilisateur MySQL
$pass = '';            // Mot de passe MySQL (vide par défaut en local)

try {
    // Création de la connexion PDO avec le jeu de caractères UTF-8
    $pdo = new PDO(
        "mysql:host=$host;dbname=$db;charset=utf8mb4", 
        $user, 
        $pass
    );
    
    // Configuration du mode d'erreur PDO pour lever des exceptions
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // En cas d'erreur, arrêt du script avec affichage du message d'erreur
    die("Erreur de connexion : " . $e->getMessage());
}
?>