<?php
/**
 * Fichier : consultation_voyages.php
 * Description : Interface de consultation des voyages avec statistiques
 * 
 * Cette page permet de visualiser :
 * - Gare de départ et d'arrivée
 * - Date de départ
 * - Durée moyenne
 * - Retards moyens au départ et à l'arrivée
 * Avec possibilité de filtrage
 */

session_start();
require 'connexion.php';

// Vérification des droits
if (!isset($_SESSION['user']) || !in_array($_SESSION['user']['droits'], ['voyageur','gestionnaire','admin'])) {
    header('Location: login.php');
    exit;
}

$role = $_SESSION['user']['droits'];
$retour_page = ($role === 'voyageur') ? 'voyageur.php' : (($role === 'admin') ? 'admin.php' : 'gestionnaire.php');

// Récupération des filtres
$gare_depart = isset($_GET['gare_depart']) ? $_GET['gare_depart'] : '';
$gare_arrivee = isset($_GET['gare_arrivee']) ? $_GET['gare_arrivee'] : '';
$date_depart = isset($_GET['date_depart']) ? $_GET['date_depart'] : '';

// Construction de la requête SQL
$sql = "SELECT 
            g1.nom AS gare_depart,
            g2.nom AS gare_arrivee,
            dv.date_depart,
            s.duree_moyenne,
            s.retard_moyen_depart_retard,
            s.retard_moyen_arrivee_retard
        FROM voyage v
        JOIN gare g1 ON v.gare_depart_id = g1.gare_id
        JOIN gare g2 ON v.gare_arrivee_id = g2.gare_id
        JOIN stats s ON v.stats_id = s.stats_id
        JOIN date_voyage dv ON v.date_id = dv.date_id
        WHERE 1=1";

$params = [];

if (!empty($gare_depart)) {
    $sql .= " AND g1.nom LIKE ?";
    $params[] = "%$gare_depart%";
}
if (!empty($gare_arrivee)) {
    $sql .= " AND g2.nom LIKE ?";
    $params[] = "%$gare_arrivee%";
}
if (!empty($date_depart)) {
    $sql .= " AND DATE(dv.date_depart) = ?";
    $params[] = $date_depart;
}

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $voyages = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = "Erreur lors du chargement des données : " . htmlspecialchars($e->getMessage());
}

// Récupération de la liste des gares pour les filtres
try {
    $stmt_gares = $pdo->query("SELECT DISTINCT nom FROM gare ORDER BY nom");
    $gares = $stmt_gares->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {
    $error = "Erreur lors du chargement des gares : " . htmlspecialchars($e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SNCF - Consultation des Voyages</title>
    <link rel="stylesheet" href="./../styles/style.css">
    <link rel="stylesheet" href="./../styles/style_tableau.css">
</head>
<body>
    <section class="hero">
        <div class="hero-content">
            <h1><span class="highlight">Tchoutchou</span> SNCF</h1>
            <p class="lead"><strong>Consultation des Voyages</strong><br>Visualiser les voyages et leurs statistiques</p>
            <a href="#contenu" class="btn-primary">Découvrir</a>
        </div>
        <div class="overlay"></div>
    </section>

    <section class="content" id="contenu">
        <div class="card">
            <!-- Formulaire de filtrage -->
            <form method="get" class="filter-form">
                <div class="form-group">
                    <label for="gare_depart">Gare de départ :</label>
                    <select name="gare_depart" id="gare_depart">
                        <option value="">Toutes les gares</option>
                        <?php foreach ($gares as $gare):
                            echo "<option value=\"" . $gare . "\" " . ($gare_depart === $gare ? 'selected' : '') . ">";
                            echo $gare;
                            echo "</option>";
                        endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="gare_arrivee">Gare d'arrivée :</label>
                    <select name="gare_arrivee" id="gare_arrivee">
                        <option value="">Toutes les gares</option>
                        <?php foreach ($gares as $gare):
                            echo "<option value=\"" . $gare . "\" " . ($gare_arrivee === $gare ? 'selected' : '') . ">";
                            echo $gare;
                            echo "</option>";
                        endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="date_depart">Date de départ :</label>
                    <input type="date" name="date_depart" id="date_depart" 
                           value="<?php echo $date_depart; ?>">
                </div>

                <button type="submit" class="btn">Filtrer</button>
                <button type="button" onclick="window.location.href='consultation_voyageur.php'" class="btn btn-secondary">Réinitialiser</button>
            </form>

            <!-- Affichage des résultats -->
            <?php if (isset($error)):
                echo "<div class=\"alert-error\">" . $error . "</div>";
            elseif (!empty($voyages)):
                echo "<h2>📊 Résultats de la recherche</h2>";
                echo "<div class=\"table-wrapper\">";
                    echo "<table>";
                    echo "<thead>";
                        echo "<tr>";
                            echo "<th>Gare de départ</th>";
                            echo "<th>Gare d'arrivée</th>";
                            echo "<th>Date de départ</th>";
                            echo "<th>Durée moyenne (min)</th>";
                            echo "<th>Retard moyen départ (min)</th>";
                            echo "<th>Retard moyen arrivée (min)</th>";
                            echo "</tr>";
                        echo "</thead>";
                        echo "<tbody>";
                            foreach ($voyages as $voyage):
                                echo "<tr>";
                                    echo "<td>" . htmlspecialchars($voyage['gare_depart']) . "</td>";
                                    echo "<td>" . htmlspecialchars($voyage['gare_arrivee']) . "</td>";
                                    echo "<td>" . htmlspecialchars($voyage['date_depart']) . "</td>";
                                    echo "<td>" . htmlspecialchars($voyage['duree_moyenne']) . "</td>";
                                    echo "<td>" . htmlspecialchars($voyage['retard_moyen_depart_retard']) . "</td>";
                                    echo "<td>" . htmlspecialchars($voyage['retard_moyen_arrivee_retard']) . "</td>";
                                echo "</tr>";
                            endforeach;
                        echo "</tbody>";
                    echo "</table>";
                echo "</div>";
            else:
                echo "<p class=\"no-results\">Aucun voyage ne correspond aux critères de recherche.</p>";
            endif; ?>
        <p class="small"><a href="<?= $retour_page?>">← Retour à l’accueil <?= $role?></a></p>
        </div>
    </section>
    <footer class="footer">
        © 2025 Tchoutchou SNCF — Tous droits réservés.
    </footer>
</body>
</html>