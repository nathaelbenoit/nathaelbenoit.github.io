<?php
/**
 * Fichier : login.php
 * Description : Gestion de l'authentification des utilisateurs
 * 
 * Ce fichier gère :
 * - L'affichage du formulaire de connexion
 * - La vérification des identifiants
 * - La redirection vers les pages appropriées selon le rôle de l'utilisateur
 */

// Démarrage de la session pour gérer l'authentification
session_start();

// Inclusion du fichier de connexion à la base de données
require 'connexion.php';

// Variable pour stocker les messages d'erreur éventuels
$error = '';

// Traitement du formulaire de connexion
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupération sécurisée des données du formulaire
    $username = isset($_POST['username']) ? $_POST['username'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    // Préparation et exécution de la requête pour vérifier les identifiants
    $stmt = $pdo->prepare("SELECT * FROM co WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    // Vérification des identifiants
    if ($user && $user['password'] === $password) {
        // Stockage des informations de l'utilisateur en session
        $_SESSION['user'] = $user;

        // Redirection selon le rôle de l'utilisateur
        switch ($user['droits']) {
            case 'admin':
                header('Location: admin.php');
                break;
            case 'gestionnaire':
                header('Location: gestionnaire.php');
                break;
            case 'voyageur':
                header('Location: voyageur.php');
                break;
        }
        exit;
    } else {
        // Message d'erreur en cas d'identifiants incorrects
        $error = "Identifiants incorrects.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tchoutchou SNCF</title>
    <link rel="stylesheet" href="./../styles/style.css">
</head>
<body class="login-page">

    <section class="content">
        <div class="login-form">
            <h2>Identifiez-vous</h2>
            <?php if (!empty($error)):
                echo "<p style=\"color: red; text-align:center;\">" . $error . "</p>";
            endif; ?>
            <form method="post">
                <label for="username">Nom d'utilisateur</label>
                <input type="text" name="username" id="username" required placeholder="Nom d'utilisateur">

                <label for="password">Mot de passe</label>
                <input type="password" name="password" id="password" required placeholder="Mot de passe">

                <button type="submit" class="btn">Se connecter</button>
            </form>

            <p class="small">
                Pas encore de compte ? <a href="./register.php">Créer un compte</a><br>      
                <a href="./../index.php">← Retour au context</a>
            </p>
        </div>
    </section>

    <footer class="footer">
        © 2025 Tchoutchou SNCF — Tous droits réservés.
    </footer>
</body>
</html>