<?php
/**
 * Fichier : visualiser_donnees.php
 * Description : Interface de visualisation des données de la base
 * 
 * Ce fichier permet aux administrateurs et gestionnaires de :
 * - Consulter le contenu des différentes tables de la base
 * - Naviguer facilement entre les différentes tables
 * - Visualiser les données dans un format tabulaire scrollable
 */

// Démarrage de la session
session_start();

// Inclusion du fichier de connexion à la base de données
require 'connexion.php';

// Vérification des droits d'accès (admin ou gestionnaire uniquement)
if (!isset($_SESSION['user']) || !in_array($_SESSION['user']['droits'], ['admin', 'gestionnaire'])) {
    header('Location: login.php');
    exit;
}

// Détermination de la page de retour en fonction du rôle de l'utilisateur
$role = $_SESSION['user']['droits'];
$retour_page = ($role === 'admin') ? 'admin.php' : 'gestionnaire.php';

// Définition des tables disponibles avec leurs libellés
$tables = [
    'gare' => 'Gares',
    'date_voyage' => 'Dates de voyage',
    'stats' => 'Statistiques',
    'voyage' => 'Voyages'
];

// Récupération de la table sélectionnée depuis l'URL
$table_selectionnee = isset($_GET['table']) ? $_GET['table'] : '';
$data = []; // Tableau pour stocker les données à afficher

if ($table_selectionnee && array_key_exists($table_selectionnee, $tables)) {
    try {
        $stmt = $pdo->query("SELECT * FROM $table_selectionnee");
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $error = "Erreur lors du chargement des données : " . htmlspecialchars($e->getMessage());
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SNCF - Visualisation Donnees</title>
    <link rel="stylesheet" href="./../styles/style.css">
    <link rel="stylesheet" href="./../styles/style_tableau.css">
    <style>
        /* Première colonne collante */
        .table-wrapper th:first-child,
        .table-wrapper td:first-child {
        position: sticky;
        left: 0;
        background: white;
        z-index: 4;
        box-shadow: 2px 0 4px rgba(0,0,0,0.05);
        }

        .table-wrapper thead th:first-child { z-index: 5; }
    </style>

</head>
<body>
    <section class="hero">
        <div class="hero-content">
            <h1><span class="highlight">Tchoutchou</span> SNCF</h1>
            <p class="lead"><strong>Visualisation des données</strong><br>Visualiser l'ensemble des tables de la base de donnée</p>
            <a href="#contenu" class="btn-primary">Découvrir</a>
        </div>
        <div class="overlay"></div>
    </section>

    <section class="content" id="contenu">
        <div class="card">

            <!-- Sélecteur -->
            <form method="get">
                <select name="table" id="table" required>
                    <option value="">-- Sélectionnez une table --</option>
                    <?php foreach ($tables as $nom => $libelle):
                        echo "<option value=".$nom." " . ($table_selectionnee === $nom ? 'selected' : '') . ">$libelle</option>";
                    endforeach; ?>
                </select>
                <button type="submit" class="btn">Afficher</button>
            </form>

            <!-- Résultats -->
            <?php if (isset($error)):
                echo "<div class=\"alert-error\">".$error."</div>";
            elseif ($table_selectionnee && !empty($data)):
                echo "<h2>📊 Table : ".$tables[$table_selectionnee]."</h2>";
            ?>
                <!-- ✅ Tableau scrollable et limité à 500px de large -->
                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <?php foreach (array_keys($data[0]) as $col):
                                    echo "<th>".$col."</th>";
                                endforeach; 
                                ?>
                            </tr>
                        </thead>
                        <tbody>    
                            <?php foreach ($data as $row):
                                echo "<tr>"; 
                                    foreach ($row as $val): 
                                        echo "<td>".$val."</td>";
                                    endforeach;
                                echo "</tr>";
                            endforeach; 
                            ?>
                        </tbody>
                    </table>
                </div>

            <?php elseif ($table_selectionnee):
                echo "<p style=\"text-align:center;\">Aucune donnée trouvée dans cette table.</p>";
            endif; ?>


            <p class="small"><a href="<?= $retour_page?>">← Retour à l’accueil <?= $role?></a></p>
        </div>
    </section>
    <footer class="footer">
        © 2025 Tchoutchou SNCF — Tous droits réservés.
    </footer>
</body>
</html>
