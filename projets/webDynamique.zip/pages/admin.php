<?php
/**
 * Fichier : admin.php
 * Description : Page d'administration principale
 * 
 * Cette page :
 * - Est accessible uniquement aux utilisateurs ayant le rôle 'admin'
 * - Propose les différentes fonctionnalités d'administration
 * - Redirige les utilisateurs non autorisés vers la page de connexion
 */

// Démarrage de la session
session_start();

// Vérification des droits d'accès
if (!isset($_SESSION['user']) || $_SESSION['user']['droits'] !== 'admin') {
    // Redirection si l'utilisateur n'est pas connecté ou n'est pas administrateur
    header('Location: login.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SNCF - Administrateur</title>
  <link rel="stylesheet" href="./../styles/style.css">
</head>
<body class="user-page">
    <section class="hero">
        <div class="hero-content">
            <h1><span class="highlight">Tchoutchou</span> SNCF</h1>
            <p class="lead">Espace Administrateur</p>
            <a href="#contenu" class="btn-primary">Découvrir</a>
        </div>
        <div class="overlay"></div>
    </section>

    <section class="content" id="contenu">
        <div class="card">
            <!-- En-tête de la page -->
            <h2>Bienvenue, administrateur</h2>
            <p class="lead">Que souhaitez-vous faire ?</p>

            <!-- Menu des fonctionnalités administrateur -->
            <ul style="list-style:none; padding:0;">
                
                <!-- Gestion des utilisateurs -->
                <li style="margin-bottom:12px;">
                    <a href="gestion_utilisateurs.php" title="Gérer les comptes utilisateurs">
                        Gestion des utilisateurs
                    </a>
                </li>
                
                <!-- Mise à jour de la base de données -->
                <li style="margin-bottom:12px;">
                    <a href="maj_db.php" title="Mettre à jour les données des trains">
                        Mise à jour de la base de données
                    </a>
                </li>
                
                <!-- Visualisation des données -->
                <li style="margin-bottom:12px;">
                    <a href="visualiser_donnees.php" title="Consulter toutes les donnees">
                        Consultation de toutes les données
                    </a>
                </li>
                
                <!-- Modification des trajets -->
                <li style="margin-bottom:12px;">
                    <a href="modifier_donnees.php" title="Modifier les informations des trajets">
                        Modification / Ajout / Suppression de trajets
                    </a>
                </li>
                <br>

                <!-- Visualisation des trajets -->
                <li style="margin-bottom:12px;">
                    <a href="consultation_voyageur.php" title="Visualisation des trajets">
                        Visualisation des trajets
                    </a>
                </li>
                <!-- Visualisation des statistiques des gares -->
                <li style="margin-bottom:12px;">
                    <a href="graphique.php" title="Visualisation des statistiques des gares">
                        Visualisation des statistiques des gares
                    </a>
                </li>
                <br>
                
                <!-- Déconnexion -->
                <li>
                    <a href="./logout.php" title="Se déconnecter de l'application">
                        Déconnexion
                    </a>
                </li>
            </ul>
        </div>
    </section>
    <footer class="footer">
        © 2025 Tchoutchou SNCF — Tous droits réservés.
    </footer>
</body>
</html>