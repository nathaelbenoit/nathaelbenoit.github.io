<?php
/**
 * Fichier : gestionnaire.php
 * Description : Page d'accueil pour les utilisateurs avec le rôle 'gestionnaire'
 * 
 * Ce fichier :
 * - Vérifie les droits d'accès
 * - Affiche le menu des fonctionnalités disponibles pour les gestionnaires
 * - Gère la navigation vers les différentes fonctionnalités
 */

// Démarrage de la session
session_start();

// Vérification des droits d'accès (rôle gestionnaire requis)
if (!isset($_SESSION['user']) || $_SESSION['user']['droits'] !== 'gestionnaire') {
    header('Location: login.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SNCF - Gestionnaire</title>
    <link rel="stylesheet" href="./../styles/style.css">
</head>
<body class="user-page">
    <section class="hero">
        <div class="hero-content">
            <h1><span class="highlight">Tchoutchou</span> SNCF</h1>
            <p class="lead">Espace Gestionnaire</p>
            <a href="#contenu" class="btn-primary">Découvrir</a>
        </div>
        <div class="overlay"></div>
  </section>

  <section class="content" id="contenu">
    <div class="card">
            <!-- En-tête de la page -->
            <h2>Bienvenue, gestionnaire</h2>
            <p class="lead">Que souhaitez-vous faire ?</p>

            <!-- Menu des fonctionnalités du gestionnaire -->
            <ul style="list-style:none; padding:0;">
                <!-- Modification des trajets -->
                <li style="margin-bottom:12px;">
                    <a href="modifier_donnees.php" title="Accéder à l'interface de modification des trajets">
                        Modification / Ajout / Suppression de trajets
                    </a>
                </li>
                
                <!-- Visualisation des données -->
                <li style="margin-bottom:12px;">
                    <a href="visualiser_donnees.php" title="Consultation de toutes les données">
                        Consultation de toutes les données
                    </a>
                </li>

                <br>
                
                <!-- Visualisation des trajets -->
                <li style="margin-bottom:12px;">
                    <a href="consultation_voyageur.php" title="Visualisation des trajets">
                        Visualisation des trajets
                    </a>
                </li>

                <!-- Visualisation des statistiques des gares -->
                <li style="margin-bottom:12px;">
                    <a href="graphique.php" title="Visualisation des statistiques des gares">
                        Visualisation des statistiques des gares
                    </a>
                </li>
                <br>
                
                <!-- Déconnexion -->
                <li>
                    <a href="./logout.php" title="Se déconnecter de l'application">
                        Déconnexion
                    </a>
                </li>
            </ul>
        </div>
    </section>  
    <footer class="footer">
        © 2025 Tchoutchou SNCF — Tous droits réservés.
    </footer>
</body>
</html>