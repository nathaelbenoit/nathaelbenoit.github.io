<?php
session_start();
require 'connexion.php';

// --- Accès autorisé à admin & gestionnaire ---
if (!isset($_SESSION['user']) || !in_array($_SESSION['user']['droits'], ['admin', 'gestionnaire'])) {
    header('Location: login.php');
    exit;
}

$role = $_SESSION['user']['droits'];
$retour_page = ($role === 'admin') ? 'admin.php' : 'gestionnaire.php';

/* ============================================================
   🧩 TRAITEMENT DES ACTIONS (AJOUT / UPDATE / DELETE)
   ============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // === AJOUT GARE ===
        if (isset($_POST['add_gare'])) {
            $nom = trim($_POST['nom']);
            if ($nom !== '') {
                $stmt = $pdo->prepare("INSERT INTO gare (nom) VALUES (?)");
                $stmt->execute([$nom]);
                $_SESSION['flash'] = ['type' => 'success', 'msg' => "✅ Nouvelle gare ajoutée."];
            }
        }

        // === AJOUT DATE ===
        if (isset($_POST['add_date'])) {
            $date_depart = trim($_POST['date_depart']);
            if ($date_depart !== '') {
                $stmt = $pdo->prepare("INSERT INTO date_voyage (date_depart) VALUES (?)");
                $stmt->execute([$date_depart]);
                $_SESSION['flash'] = ['type'=>'success','msg'=>"✅ Nouvelle date ajoutée."];
            }
        }

        // === AJOUT STATISTIQUE ===
        if (isset($_POST['add_stats'])) {
            $stmt = $pdo->prepare("INSERT INTO stats (duree_moyenne, retard_moyen_depart_retard, nb_circulations,
            nb_retard_depart,nb_retard_arrivee,retard_moyen_arrivee_retard,retard_moyen_arrivee_total,
            nb_retard_15,retard_moyen_15,nb_retard_60,prct_retard_externe,prct_retard_infra,prct_retard_materiel,
            prct_retard_gare,prct_retard_voyageurs) VALUES (?, ?, ?, ?, ?, ?,?,?,?,?,?,?,?,?,?)");
            $stmt->execute([
                $_POST['duree_moyenne'],
                $_POST['retard_moyen_depart_retard'],
                $_POST['nb_circulations'],
                $_POST['nb_retard_depart'],
                $_POST['nb_retard_arrivee'],
                $_POST['retard_moyen_arrivee_retard'],
                $_POST['retard_moyen_arrivee_total'],
                $_POST['nb_retard_15'],
                $_POST['retard_moyen_15'],
                $_POST['nb_retard_60'],
                $_POST['prct_retard_externe'],
                $_POST['prct_retard_infra'],
                $_POST['prct_retard_materiel'],
                $_POST['prct_retard_gare'],
                $_POST['prct_retard_voyageurs']
            ]);
            $_SESSION['flash'] = ['type'=>'success','msg'=>"✅ Nouvelle statistique ajoutée."];
        }

        // === AJOUT VOYAGE ===
        if (isset($_POST['add_voyage'])) {
            $stmt = $pdo->prepare("
                INSERT INTO voyage (stats_id, gare_depart_id, gare_arrivee_id, date_id)
                VALUES (?, ?, ?, ?)
            ");
            $stmt->execute([
                $_POST['stats_id'],
                $_POST['gare_depart_id'],
                $_POST['gare_arrivee_id'],
                $_POST['date_id']
            ]);
            $_SESSION['flash'] = ['type'=>'success','msg'=>"✅ Nouveau voyage ajouté."];
        }

    } catch (Exception $e) {
        $_SESSION['flash'] = ['type'=>'error','msg'=>"❌ Erreur inattendue : " . htmlspecialchars($e->getMessage())];
    }

    header("Location: " . strtok($_SERVER['REQUEST_URI'], '?'));
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SNCF - Ajout Donnees</title>
    <link rel="stylesheet" href="./../styles/style.css">
    <style>
        td {
            border-bottom: 0px solid #ccc;
        }
    </style>
</head>
<body>
    <section class="hero">
        <div class="hero-content">
            <h1><span class="highlight">Tchoutchou</span> SNCF</h1>
            <p class="lead"><strong>Gestion des données</strong><br>Ajouter, modifier ou supprimer des enregistrements</p>
            <a href="#contenu" class="btn-primary">Découvrir</a>
        </div>
        <div class="overlay"></div>
    </section>

    <section class="content" id="contenu">
        <div class="card">
            <div style="text-align: center; margin-top: 20px;">
                <a href="./modifier_donnees.php">Modifier des données</a>
            </div>

            <?php if (!empty($_SESSION['flash'])): $f=$_SESSION['flash'];unset($_SESSION['flash']);?>
            <div class="alert <?= $f['type']==='success'?'alert-success':'alert-error' ?>">
            <?= $f['msg'] ?>
            </div>
            <?php endif; ?>

            <!-- === AJOUT GARE === -->
            <table>
                <tr><td><h2>🚉 Gares</h2></td></tr>
                <tr>
                    <form method="post" class="actions">
                        <td><input type="text" name="nom" placeholder="Nom de la gare" required></td>
                        <td><button type="submit" name="add_gare" class="btn">Ajouter</button></td>
                    </form>
                </tr>

                <!-- === AJOUT DATE === -->
                <tr><td><h2>📅 Dates de voyage</h2></td></tr>
                <tr>
                    <form method="post" class="actions">
                        <td><input type="date" name="date_depart" required></td>
                        <td><button type="submit" name="add_date" class="btn">Ajouter</button></td>
                    </form>
                </tr>

                <!-- === AJOUT STATISTIQUES === -->
                <tr><td><h2>📊 Statistiques</h2></td></tr>
                <form method="post" class="actions">
                    <tr>
                        <td><input type="number" name="duree_moyenne" min="0" placeholder="Durée moyenne" required></td>
                        <td><input type="number" name="nb_circulations" min="0" placeholder="Nb circulations" required></td>
                    </tr>
                    <tr>
                        <td><input type="number" name="nb_retard_depart" min="0"  placeholder="Nb retards départ" required></td>
                        <td><input type="number" name="retard_moyen_depart_retard" min="0" step="0.01" placeholder="Retard moyen départ" required></td>
                    </tr>
                    <tr>
                        <td><input type="number" name="nb_retard_arrivee" min="0" placeholder="Nb retards arrivée" required></td>
                        <td><input type="number" name="retard_moyen_arrivee_retard" min="0" step="0.01" placeholder="Retard moyen arrivée" required></td>
                    </tr>
                    <tr>
                        <td><input type="number" name="retard_moyen_arrivee_total" min="0" step="0.01" placeholder="Retard moyen arrivée total" required></td>
                        <td><input type="number" name="nb_retard_15" min="0" placeholder="Nb retards 15" required></td>
                    </tr>
                    <tr>
                        <td><input type="number" name="retard_moyen_15" min="0" step="0.01" placeholder="Retard moyen 15" required></td>
                        <td><input type="number" name="nb_retard_60" min="0" placeholder="Nb retards 60" required></td>
                    </tr>
                    <tr>
                        <td><input type="number" name="prct_retard_externe" min="0" step="0.01" placeholder="Pourcentage retards externes" required></td>
                        <td><input type="number" name="prct_retard_infra" min="0" step="0.01" placeholder="Pourcentage retards infra" required></td>
                    </tr>
                    <tr>
                        <td><input type="number" name="prct_retard_materiel" min="0" step="0.01" placeholder="Pourcentage retards matériel" required></td>
                        <td><input type="number" name="prct_retard_gare" min="0" step="0.01" placeholder="Pourcentage retards gare" required></td>
                    </tr>
                    <tr>
                        <td><input type="number" name="prct_retard_voyageurs" min="0" step="0.01" placeholder="Pourcentage retards voyageurs" required></td>
                        </tr>
                    <tr>
                        <td></td>
                        <td><button type="submit" name="add_stats" class="btn">Ajouter</button></td>
                    </tr>
                </form>

                <!-- === AJOUT VOYAGES === -->
                <tr><td><h2>🚆 Voyages</h2></td></tr>
                <form method="post" class="actions">
                    <tr>
                        <td><input type="number" min="1" name="stats_id" placeholder="Stats ID" required></td>
                        <td><input type="number" min="1" name="gare_depart_id" placeholder="Gare départ ID" required></td>
                    </tr>
                    <tr>
                        <td><input type="number" min="1" name="gare_arrivee_id" placeholder="Gare arrivée ID" required></td>
                        <td><input type="number" min="1" name="date_id" placeholder="Date ID" required></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><button type="submit" name="add_voyage" class="btn">Ajouter</button></td>
                    </tr>
                </form>

            </table>
            <p class="small"><a href="<?= $retour_page ?>">← Retour à l’accueil <?= $role ?></a></p>
        </div>
    </section>
    <footer class="footer">
        © 2025 Tchoutchou SNCF — Tous droits réservés.
    </footer>
    </body>
</html>
