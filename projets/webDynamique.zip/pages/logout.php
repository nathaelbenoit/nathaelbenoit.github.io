<?php
/**
 * Fichier : logout.php
 * Description : Gestion de la déconnexion des utilisateurs
 * 
 * Ce fichier :
 * 1. Démarre la session
 * 2. Détruit toutes les données de session
 * 3. Redirige l'utilisateur vers la page de connexion
 */

// Démarrage de la session pour accéder aux variables de session
session_start();

// Destruction de toutes les données de la session
session_destroy();

// Redirection vers la page de connexion
header('Location: login.php');

// Arrêt de l'exécution du script
exit;
?>