<?php
/**
 * Fichier : voyageur.php
 * Description : Page principale pour les voyageurs
 */

session_start();
require 'connexion.php';

// Vérification des droits
if (!isset($_SESSION['user']) || !in_array($_SESSION['user']['droits'], ['voyageur','gestionnaire','admin'])) {
    header('Location: login.php');
    exit;
}

$role = $_SESSION['user']['droits'];
$retour_page = ($role === 'voyageur') ? 'voyageur.php' : (($role === 'admin') ? 'admin.php' : 'gestionnaire.php');

// === Retard moyen à l’arrivée par gare ===
$sql1 = "
SELECT g.nom AS gare_depart, ROUND(AVG(s.retard_moyen_arrivee_total),2) AS retard_moyen
FROM voyage v
JOIN gare g ON v.gare_depart_id = g.gare_id
JOIN stats s ON v.stats_id = s.stats_id
GROUP BY g.nom
ORDER BY retard_moyen DESC;";
$gareData = $pdo->query($sql1)->fetchAll(PDO::FETCH_ASSOC);
$labelsGare = array_column($gareData, 'gare_depart');
$valuesGare = array_column($gareData, 'retard_moyen');

// === Retard moyen à l’arrivée par mois ===
$sql2 = "
SELECT d.date_depart, ROUND(AVG(s.retard_moyen_arrivee_total),2) AS retard_moyen
FROM voyage v
JOIN date_voyage d ON v.date_id = d.date_id
JOIN stats s ON v.stats_id = s.stats_id
GROUP BY d.date_depart
ORDER BY d.date_depart ASC;";
$dateData = $pdo->query($sql2)->fetchAll(PDO::FETCH_ASSOC);
$labelsDate = array_column($dateData, 'date_depart');
$valuesDate = array_column($dateData, 'retard_moyen');

// === Nombre de circulations par gare ===
$sql3 = "
SELECT g.nom AS gare_depart, SUM(s.nb_circulations) AS nb_circ
FROM voyage v
JOIN gare g ON v.gare_depart_id = g.gare_id
JOIN stats s ON v.stats_id = s.stats_id
GROUP BY g.nom
ORDER BY nb_circ DESC;";
$circData = $pdo->query($sql3)->fetchAll(PDO::FETCH_ASSOC);
$labelsCirc = array_column($circData, 'gare_depart');
$valuesCirc = array_column($circData, 'nb_circ');

// === Causes de retard ===
$sql4 = "
SELECT ROUND(AVG(prct_retard_externe),2) AS externe,
       ROUND(AVG(prct_retard_infra),2) AS infra,
       ROUND(AVG(prct_retard_materiel),2) AS materiel,
       ROUND(AVG(prct_retard_gare),2) AS gare,
       ROUND(AVG(prct_retard_voyageurs),2) AS voyageurs
FROM stats;";
$causes = $pdo->query($sql4)->fetch(PDO::FETCH_ASSOC);

// === Répartition des retards ===
$sql5 = "
SELECT SUM(nb_retard_15) AS retard_15,
       SUM(nb_retard_60) AS retard_60,
       (SUM(nb_retard_arrivee) - SUM(nb_retard_60) - SUM(nb_retard_15)) AS retard_plus_60
FROM stats;";
$retards = $pdo->query($sql5)->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SNCF - Statistiques des gares</title>
<link rel="stylesheet" href="./../styles/style.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

</head>
<body>
  <section class="hero">
    <div class="hero-content">
      <h1><span class="highlight">Tchoutchou</span> SNCF</h1>
      <p class="lead"><strong>Visualisation des statistiques</strong><br>Visualiser les statistiques des gares, de leurs retards et de leurs circulations</p>
      <a href="#contenu" class="btn-primary">Découvrir</a>
    </div>
    <div class="overlay"></div>
  </section>

  <section class="content" id="contenu">
    <div class="card">

      <div class="graph-card">
        <h2>Retard moyen à l’arrivée par gare (en min)</h2>
        <canvas id="chartGares"></canvas>
      </div>

      <div class="graph-card">
        <h2>Retard moyen à l’arrivée par mois (en min)</h2>
        <canvas id="chartJours"></canvas>
      </div>

      <div class="graph-card">
        <h2>Nombre de circulations par gare</h2>
        <canvas id="chartCirc"></canvas>
      </div>

      <!-- Graphiques 4 et 5 côte à côte -->
      <div class="charts-row">
        <div class="chart-box">
          <h2>Causes moyennes des retards (%)</h2>
          <canvas id="chartCauses"></canvas>
        </div>
        <div class="chart-box">
          <h2>Répartition des retards (durées)</h2>
          <canvas id="chartRepartition"></canvas>
        </div>
      </div>

      <script>
      // === GRAPHIQUE 1 ===
      new Chart(document.getElementById('chartGares'), {
        type: 'bar',
        data: {
          labels: <?= json_encode($labelsGare, JSON_UNESCAPED_UNICODE) ?>,
          datasets: [{
            label: 'Retard moyen (min)',
            data: <?= json_encode($valuesGare, JSON_NUMERIC_CHECK) ?>,
            backgroundColor: '#FF3B8B',
            borderColor: '#FF3B8B',
            borderWidth: 1
          }]
        },
        options: { responsive: true, plugins:{legend:{display:false}} }
      });

      // === GRAPHIQUE 2 ===
      new Chart(document.getElementById('chartJours'), {
        type: 'line',
        data: {
          labels: <?= json_encode($labelsDate, JSON_UNESCAPED_UNICODE) ?>,
          datasets: [{
            label: 'Retard moyen (min)',
            data: <?= json_encode($valuesDate, JSON_NUMERIC_CHECK) ?>,
            borderColor: '#6C1D6F',
            tension: 0.3,
            fill: false
          }]
        },
        options: { responsive: true }
      });

      // === GRAPHIQUE 3 ===
      new Chart(document.getElementById('chartCirc'), {
        type: 'bar',
        data: {
          labels: <?= json_encode($labelsCirc, JSON_UNESCAPED_UNICODE) ?>,
          datasets: [{
            label: 'Nombre de circulations',
            data: <?= json_encode($valuesCirc, JSON_NUMERIC_CHECK) ?>,
            backgroundColor: '#FF0019',
            borderColor: '#FF0019',
            borderWidth: 1
          }]
        },
        options: { responsive: true }
      });

      // === GRAPHIQUE 4 ===
      new Chart(document.getElementById('chartCauses'), {
        type: 'pie',
        data: {
          labels: ['Externe','Infrastructure','Matériel','Gare','Voyageurs'],
          datasets: [{
            data: [
              <?= $causes['externe'] ?>,
              <?= $causes['infra'] ?>,
              <?= $causes['materiel'] ?>,
              <?= $causes['gare'] ?>,
              <?= $causes['voyageurs'] ?>
            ],
            backgroundColor: ['#FF0019','#FF2057','#FF3B8B','#AD2A7B','#6C1D6F']
          }]
        },
        options: { responsive: true, plugins:{legend:{position:'bottom'}} }
      });

      // === GRAPHIQUE 5 ===
      new Chart(document.getElementById('chartRepartition'), {
        type: 'doughnut',
        data: {
          labels: ['≤ 15 min', '≤ 60 min', '> 60 min'],
          datasets: [{
            data: [
              <?= $retards['retard_15'] ?>,
              <?= $retards['retard_60'] ?>,
              <?= $retards['retard_plus_60'] ?>
            ],
            backgroundColor: ['#6c1d6f','#ff3b8b','#ff0019']
          }]
        },
        options: { responsive: true, plugins:{legend:{position:'bottom'}} }
      });
      </script>

      <p class="small"><a href="<?= $retour_page ?>">← Retour à l’accueil <?= $role?></a></p>
    </div> <!-- fermeture de .card -->
  </section>
  <footer class="footer">
      © 2025 Tchoutchou SNCF — Tous droits réservés.
  </footer>
</body>
</html>



