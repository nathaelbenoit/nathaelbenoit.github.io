<?php
/**
 * Fichier : register.php
 * Description : Gestion de l'inscription des nouveaux utilisateurs
 * 
 * Ce fichier permet :
 * - L'affichage du formulaire d'inscription
 * - La validation des données saisies
 * - La création de nouveaux comptes utilisateurs
 * - L'attribution automatique du rôle 'voyageur'
 */

// Démarrage de la session
session_start();

// Inclusion du fichier de connexion à la base de données
require 'connexion.php';

// Variables pour gérer les messages
$error = '';    // Stocke les messages d'erreur
$success = '';  // Stocke les messages de succès

// Traitement du formulaire d'inscription
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Nettoyage des données reçues
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $droits = 'voyageur'; // Rôle par défaut pour tous les nouveaux utilisateurs

    // Étape 1 : Vérification de l'unicité du nom d'utilisateur
    $stmt = $pdo->prepare("SELECT * FROM co WHERE username = ?");
    $stmt->execute([$username]);
    if ($stmt->fetch()) {
        // L'utilisateur existe déjà
        $error = "Ce nom d'utilisateur est déjà pris.";
    } else {
        // Étape 2 : Création du nouveau compte
        $stmt = $pdo->prepare("INSERT INTO co (username, password, droits) VALUES (?, ?, ?)");
        if ($stmt->execute([$username, $password, $droits])) {
            // Succès de la création
            $success = "Compte créé avec succès. Vous pouvez maintenant vous connecter.";
        } else {
            // Échec de la création
            $error = "Erreur lors de la création du compte.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SNCF - Enregistrement</title>
    <link rel="stylesheet" href="./../styles/style.css">
</head>
<body class="login-page">

    <section class="content">
        <div class="login-form">
            <!-- En-tête du formulaire -->
            <h2>Créer un compte</h2>
            <p class="lead">Remplissez les champs pour vous inscrire</p>

            <!-- Affichage des messages d'erreur -->
            <?php if ($error): 
                echo "<div class=\"alert\">".$error."</div>";
            endif; ?>

            <!-- Affichage des messages de succès -->
            <?php if ($success): 
                echo "<div class=\"alert\" style=\"color:green\">".$success."</div>";
            endif; ?>

            <!-- Formulaire d'inscription -->
            <form method="post">
                <!-- Champ nom d'utilisateur -->
                <label for="username">Nom d'utilisateur</label>
                <input type="text" 
                       name="username" 
                       id="username" 
                       required 
                       placeholder="Choisissez un nom d'utilisateur">

                <!-- Champ mot de passe -->
                <label for="password">Mot de passe</label>
                <input type="password" 
                       name="password" 
                       id="password" 
                       required 
                       placeholder="Choisissez un mot de passe">

                <!-- Bouton de soumission -->
                <button type="submit" class="btn">Créer le compte</button>
            </form>

            <!-- Lien de retour -->
            <p class="small"><a href="./login.php">← Retour à la connexion</a></p>
        </div>
    </section>
    <footer class="footer">
        © 2025 Tchoutchou SNCF — Tous droits réservés.
    </footer>
</body>
</html>