   CREATE DATABASE IF NOT EXISTS `tchoutchou` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
   USE `tchoutchou`;

   CREATE TABLE IF NOT EXISTS `co` (
   `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
   `username` VARCHAR(100) NOT NULL UNIQUE,
   `password` VARCHAR(255) NOT NULL,
   `droits` ENUM('voyageur','admin','gestionnaire') NOT NULL DEFAULT 'voyageur',
   `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
   PRIMARY KEY (`id`)
   ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

   INSERT INTO `co` (`username`, `password`, `droits`)
   VALUES
   ('admin_user', 'admin123', 'admin'),
   ('gestion_user', 'gestion123', 'gestionnaire'),
   ('voyageur_user', 'voyageur123', 'voyageur')
   ON DUPLICATE KEY UPDATE
   `password` = VALUES(`password`),
   `droits` = VALUES(`droits`);

   CREATE TABLE IF NOT EXISTS `gare` (
      `gare_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
      `nom` VARCHAR(50) NOT NULL UNIQUE,
      PRIMARY KEY(`gare_id`)
   ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

   CREATE TABLE IF NOT EXISTS `stats` (
      `stats_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
      `duree_moyenne` INT,
      `nb_circulations` INT,
      `nb_retard_depart` INT,
      `retard_moyen_depart_retard` DECIMAL(15,2),
      `nb_retard_arrivee` INT,
      `retard_moyen_arrivee_retard` DECIMAL(15,2),
      `retard_moyen_arrivee_total` DECIMAL(15,2),
      `nb_retard_15` INT,
      `retard_moyen_15` DECIMAL(15,2),
      `nb_retard_60` INT,
      `prct_retard_externe` DECIMAL(15,2),
      `prct_retard_infra` DECIMAL(15,2),
      `prct_retard_materiel` DECIMAL(15,2),
      `prct_retard_gare` DECIMAL(15,2),
      `prct_retard_voyageurs` DECIMAL(15,2),
      PRIMARY KEY(`stats_id`)
   )ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

   CREATE TABLE IF NOT EXISTS `date_voyage` (
      `date_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
      `date_depart` DATE NOT NULL UNIQUE,
      PRIMARY KEY(`date_id`)
   ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

   CREATE TABLE IF NOT EXISTS `voyage` (
      `voyage_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
      `stats_id` INT UNSIGNED NOT NULL,
      `gare_depart_id` INT UNSIGNED NOT NULL,
      `gare_arrivee_id` INT UNSIGNED NOT NULL,
      `date_id` INT UNSIGNED NOT NULL,
      PRIMARY KEY(`voyage_id`),  
      FOREIGN KEY(`stats_id`) REFERENCES `stats`(`stats_id`),
      FOREIGN KEY(`gare_depart_id`) REFERENCES `gare`(`gare_id`),
      FOREIGN KEY(`gare_arrivee_id`) REFERENCES `gare`(`gare_id`),
      FOREIGN KEY(`date_id`) REFERENCES `date_voyage`(`date_id`)
   ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


