# Documentation du Projet

## Description Générale
Ce projet est une application web développée pour un projet universitaire. Il inclut des fonctionnalités telles que la gestion des utilisateurs, l'ajout et la visualisation des données, ainsi que la gestion des droits d'accès. Le projet est structuré autour de plusieurs pages PHP et utilise des fichiers SQL et CSV pour la gestion des données.

## Structure du Projet
Voici un aperçu des principaux dossiers et fichiers du projet :

- **index.php** : Page d'accueil du projet.
- **files/** : Contient les fichiers nécessaires pour la base de données et les permissions.
  - `creation_tables.sql` : Script SQL pour créer les tables nécessaires dans la base de données.
  - `matrice_permissions.csv` : Fichier CSV définissant les permissions des utilisateurs.
  - `MCD_tchoutchou.loo` : Modèle conceptuel de données (MCD).
  - `Model UML.png` : Modèle des droits des utilisateurs
  - `regularite-mensuelle-tgv-aqst.csv` : Données sur la régularité mensuelle des TGV.
- **pages/** : Contient les différentes pages PHP pour les fonctionnalités du projet.
  - `admin.php` : Interface d'administration.
  - `ajout_donnees.php` : Permet d'ajouter des données dans la base.
  - `connexion.php` : Gère la connexion des utilisateurs.
  - `consultation_voyageur.php` : Permet de visualiser les trajets pour les voyageurs.
  - `gestion_utilisateurs.php` : Permet de gérer les utilisateurs.
  - `gestionnaire.php` : Page pour les gestionnaires.
  - `graphique.php` : Page pour voir les statistiques des gares.
  - `login.php` : Page de connexion.
  - `logout.php` : Gère la déconnexion des utilisateurs.
  - `maj_db.php` : Met à jour la base de données.
  - `modifier_donnees.php` : Permet de modifier des données existantes.
  - `register.php` : Permet l'inscription des utilisateurs.
  - `visualiser_donnees.php` : Permet de visualiser les données.
  - `voyageur.php` : Page dédiée aux voyageurs.
- **styles/** : Contient les fichiers CSS pour le style de l'application.
  - `style.css` : Feuille de style principale.

## Fonctionnalités Principales

1. **Gestion des Utilisateurs**
   - Inscription, connexion et déconnexion.
   - Gestion des rôles et des permissions via `matrice_permissions.csv`.

2. **Gestion des Données**
   - Ajout, modification et visualisation des données.
   - Utilisation de fichiers CSV pour importer/exporter des données.

3. **Administration**
   - Interface pour les administrateurs afin de gérer les utilisateurs et les permissions.
   - Mise à jour de la base de données via des scripts SQL.

## Installation et Configuration

1. **Prérequis**
   - Serveur web (par exemple, EasyPHP, XAMPP).
   - PHP 7.0 ou supérieur.
   - Base de données MySQL.

2. **Installation**
   - Copier les fichiers du projet dans le répertoire racine du serveur web.
   - Modifier upload_max_filesize = 2M -> upload_max_filesize = 3M dans php.ini ( C:\...\EasyPHP-Devserver-17\eds-binaries\php\php8.0\php.ini )
   - Importer le fichier `creation_tables.sql` dans votre base de données MySQL.
   - Configurer les paramètres de connexion à la base de données dans les fichiers PHP concernés.

3. **Lancement**
   - Accéder à l'application via un navigateur web en entrant l'URL correspondante (par exemple, `http://localhost/`).
   - Se connecter avec les identifiants et mots de passe ajouté lors de la création de la base ou créer un nouveau compte.

## Auteurs
Ce projet a été développé par BENOIT Nathaël, CHAUVIN Rose et CARRACO Camille.
